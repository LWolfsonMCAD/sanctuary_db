# WordPress MySQL database migration
#
# Generated: Saturday 14. March 2015 21:13 UTC
# Hostname: localhost
# Database: `sanctuary_db`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_commentmeta`
#
INSERT INTO `wp_commentmeta` ( `meta_id`, `comment_id`, `meta_key`, `meta_value`) VALUES
(1, 1, '_wp_trash_meta_status', '1'),
(2, 1, '_wp_trash_meta_time', '1425832613') ;

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2015-02-16 19:52:16', '2015-02-16 19:52:16', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, 'post-trashed', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_gallery_galleries`
#

DROP TABLE IF EXISTS `wp_gallery_galleries`;


#
# Table structure of table `wp_gallery_galleries`
#

CREATE TABLE `wp_gallery_galleries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_gallery_galleries`
#
INSERT INTO `wp_gallery_galleries` ( `id`, `title`, `created`, `modified`) VALUES
(1, 'Orchard Painter\'s Cabin', '2015-03-14 18:58:30', '2015-03-14 18:58:47') ;

#
# End of data contents of table `wp_gallery_galleries`
# --------------------------------------------------------



#
# Delete any existing table `wp_gallery_galleriesslides`
#

DROP TABLE IF EXISTS `wp_gallery_galleriesslides`;


#
# Table structure of table `wp_gallery_galleriesslides`
#

CREATE TABLE `wp_gallery_galleriesslides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_id` int(11) NOT NULL DEFAULT '0',
  `slide_id` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `gallery_id` (`gallery_id`),
  KEY `slide_id` (`slide_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_gallery_galleriesslides`
#
INSERT INTO `wp_gallery_galleriesslides` ( `id`, `gallery_id`, `slide_id`, `order`, `created`, `modified`) VALUES
(1, 1, 1, 0, '2015-03-14 18:59:28', '2015-03-14 18:59:28'),
(2, 1, 2, 0, '2015-03-14 18:59:28', '2015-03-14 18:59:28'),
(3, 1, 3, 0, '2015-03-14 18:59:28', '2015-03-14 18:59:28') ;

#
# End of data contents of table `wp_gallery_galleriesslides`
# --------------------------------------------------------



#
# Delete any existing table `wp_gallery_slides`
#

DROP TABLE IF EXISTS `wp_gallery_slides`;


#
# Table structure of table `wp_gallery_slides`
#

CREATE TABLE `wp_gallery_slides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `showinfo` varchar(50) NOT NULL DEFAULT 'both',
  `iopacity` int(11) NOT NULL DEFAULT '70',
  `image` text NOT NULL,
  `type` enum('media','file','url') NOT NULL DEFAULT 'file',
  `image_url` text NOT NULL,
  `attachment_id` int(11) NOT NULL DEFAULT '0',
  `uselink` enum('Y','N') NOT NULL DEFAULT 'N',
  `linktarget` enum('self','blank') NOT NULL DEFAULT 'self',
  `link` varchar(200) NOT NULL DEFAULT '',
  `order` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_gallery_slides`
#
INSERT INTO `wp_gallery_slides` ( `id`, `title`, `description`, `showinfo`, `iopacity`, `image`, `type`, `image_url`, `attachment_id`, `uselink`, `linktarget`, `link`, `order`, `created`, `modified`) VALUES
(1, 'cabin1', '', 'both', 70, 'cabin1.jpg', 'media', 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/cabin1.jpg', 150, 'N', 'self', '', 0, '2015-03-14 18:59:28', '2015-03-14 18:59:28'),
(2, 'cabin2', '', 'both', 70, 'cabin2.jpg', 'media', 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/cabin2.jpg', 151, 'N', 'self', '', 0, '2015-03-14 18:59:28', '2015-03-14 18:59:28'),
(3, 'cabin3', '', 'both', 70, 'cabin3.jpg', 'media', 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/cabin3.jpg', 152, 'N', 'self', '', 0, '2015-03-14 18:59:28', '2015-03-14 18:59:28') ;

#
# End of data contents of table `wp_gallery_slides`
# --------------------------------------------------------



#
# Delete any existing table `wp_huge_itslider_images`
#

DROP TABLE IF EXISTS `wp_huge_itslider_images`;


#
# Table structure of table `wp_huge_itslider_images`
#

CREATE TABLE `wp_huge_itslider_images` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `slider_id` varchar(200) DEFAULT NULL,
  `description` text,
  `image_url` text,
  `sl_url` varchar(128) DEFAULT NULL,
  `sl_type` text NOT NULL,
  `link_target` text NOT NULL,
  `sl_stitle` text NOT NULL,
  `sl_sdesc` text NOT NULL,
  `sl_postlink` text NOT NULL,
  `ordering` int(11) NOT NULL,
  `published` tinyint(4) unsigned DEFAULT NULL,
  `published_in_sl_width` tinyint(4) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_huge_itslider_images`
#
INSERT INTO `wp_huge_itslider_images` ( `id`, `name`, `slider_id`, `description`, `image_url`, `sl_url`, `sl_type`, `link_target`, `sl_stitle`, `sl_sdesc`, `sl_postlink`, `ordering`, `published`, `published_in_sl_width`) VALUES
(1, '', '1', '', 'http://sanctuary.lisawolfsonmyers.com/wp-content/plugins/slider-image/Front_images/slides/slide1.jpg', 'http://huge-it.com', 'image', 'on', '', '', '', 1, 1, NULL),
(2, 'Simple Usage', '1', '', 'http://sanctuary.lisawolfsonmyers.com/wp-content/plugins/slider-image/Front_images/slides/slide2.jpg', 'http://huge-it.com', 'image', 'on', '', '', '', 2, 1, NULL),
(3, 'Huge-IT Slider', '1', 'The slider allows having unlimited amount of images with their titles and descriptions. The slider uses autogenerated shortcodes making it easier for the users to add it to the custom location.', 'http://sanctuary.lisawolfsonmyers.com/wp-content/plugins/slider-image/Front_images/slides/slide3.jpg', 'http://huge-it.com', 'image', 'on', '', '', '', 3, 1, NULL),
(5, '', '2', '', 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/homepage2.jpg', '', '', '', '', '', '', 1, 2, 1),
(6, '', '2', '', 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/homepage3.jpg', '', '', '', '', '', '', 2, 2, 1),
(7, '', '2', '', 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/homepage4.jpg', '', '', '', '', '', '', 3, 2, 1),
(8, '', '2', '', 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/homepage5.jpg', '', '', '', '', '', '', 4, 2, 1),
(9, '', '2', '', 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/homepage1.jpg', '', '', '', '', '', '', 0, 2, 1) ;

#
# End of data contents of table `wp_huge_itslider_images`
# --------------------------------------------------------



#
# Delete any existing table `wp_huge_itslider_params`
#

DROP TABLE IF EXISTS `wp_huge_itslider_params`;


#
# Table structure of table `wp_huge_itslider_params`
#

CREATE TABLE `wp_huge_itslider_params` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `title` varchar(200) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `value` varchar(200) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=126 DEFAULT CHARSET=latin1;


#
# Data contents of table `wp_huge_itslider_params`
#
INSERT INTO `wp_huge_itslider_params` ( `id`, `name`, `title`, `description`, `value`) VALUES
(89, 'slider_crop_image', 'Slider crop image', 'Slider crop image', 'resize'),
(90, 'slider_title_color', 'Slider title color', 'Slider title color', '000000'),
(91, 'slider_title_font_size', 'Slider title font size', 'Slider title font size', '13'),
(92, 'slider_description_color', 'Slider description color', 'Slider description color', 'ffffff'),
(93, 'slider_description_font_size', 'Slider description font size', 'Slider description font size', '13'),
(94, 'slider_title_position', 'Slider title position', 'Slider title position', 'right-top'),
(95, 'slider_description_position', 'Slider description position', 'Slider description position', 'right-bottom'),
(96, 'slider_title_border_size', 'Slider Title border size', 'Slider Title border size', '0'),
(97, 'slider_title_border_color', 'Slider title border color', 'Slider title border color', 'ffffff'),
(98, 'slider_title_border_radius', 'Slider title border radius', 'Slider title border radius', '4'),
(99, 'slider_description_border_size', 'Slider description border size', 'Slider description border size', '0'),
(100, 'slider_description_border_color', 'Slider description border color', 'Slider description border color', 'ffffff'),
(101, 'slider_description_border_radius', 'Slider description border radius', 'Slider description border radius', '0'),
(102, 'slider_slideshow_border_size', 'Slider border size', 'Slider border size', '0'),
(103, 'slider_slideshow_border_color', 'Slider border color', 'Slider border color', 'ffffff'),
(104, 'slider_slideshow_border_radius', 'Slider border radius', 'Slider border radius', '0'),
(105, 'slider_navigation_type', 'Slider navigation type', 'Slider navigation type', '1'),
(106, 'slider_navigation_position', 'Slider navigation position', 'Slider navigation position', 'bottom'),
(107, 'slider_title_background_color', 'Slider title background color', 'Slider title background color', 'ffffff'),
(108, 'slider_description_background_color', 'Slider description background color', 'Slider description background color', '000000'),
(109, 'slider_title_transparent', 'Slider title has background', 'Slider title has background', 'on'),
(110, 'slider_description_transparent', 'Slider description has background', 'Slider description has background', 'on'),
(111, 'slider_slider_background_color', 'Slider slider background color', 'Slider slider background color', 'ffffff'),
(112, 'slider_dots_position', 'slider dots position', 'slider dots position', 'top'),
(113, 'slider_active_dot_color', 'slider active dot color', '', 'ffffff'),
(114, 'slider_dots_color', 'slider dots color', '', '000000'),
(115, 'slider_description_width', 'Slider description width', 'Slider description width', '70'),
(116, 'slider_description_height', 'Slider description height', 'Slider description height', '50'),
(117, 'slider_description_background_transparency', 'slider description background transparency', 'slider description background transparency', '70'),
(118, 'slider_description_text_align', 'description text-align', 'description text-align', 'justify'),
(119, 'slider_title_width', 'slider title width', 'slider title width', '30'),
(120, 'slider_title_height', 'slider title height', 'slider title height', '50'),
(121, 'slider_title_background_transparency', 'slider title background transparency', 'slider title background transparency', '70'),
(122, 'slider_title_text_align', 'title text-align', 'title text-align', 'right'),
(123, 'slider_title_has_margin', 'title has margin', 'title has margin', 'on'),
(124, 'slider_description_has_margin', 'description has margin', 'description has margin', 'on'),
(125, 'slider_show_arrows', 'Slider show left right arrows', 'Slider show left right arrows', 'on') ;

#
# End of data contents of table `wp_huge_itslider_params`
# --------------------------------------------------------



#
# Delete any existing table `wp_huge_itslider_sliders`
#

DROP TABLE IF EXISTS `wp_huge_itslider_sliders`;


#
# Table structure of table `wp_huge_itslider_sliders`
#

CREATE TABLE `wp_huge_itslider_sliders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `sl_height` int(11) unsigned DEFAULT NULL,
  `sl_width` int(11) unsigned DEFAULT NULL,
  `pause_on_hover` text,
  `slider_list_effects_s` text,
  `description` text,
  `param` text,
  `sl_position` text NOT NULL,
  `ordering` int(11) NOT NULL,
  `published` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_huge_itslider_sliders`
#
INSERT INTO `wp_huge_itslider_sliders` ( `id`, `name`, `sl_height`, `sl_width`, `pause_on_hover`, `slider_list_effects_s`, `description`, `param`, `sl_position`, `ordering`, `published`) VALUES
(2, 'Homepage', 724, 960, 'off', 'fade', '4000', '1000', 'center', 1, '300') ;

#
# End of data contents of table `wp_huge_itslider_sliders`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_ngg_album`
#

DROP TABLE IF EXISTS `wp_ngg_album`;


#
# Table structure of table `wp_ngg_album`
#

CREATE TABLE `wp_ngg_album` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `previewpic` bigint(20) NOT NULL DEFAULT '0',
  `albumdesc` mediumtext,
  `sortorder` longtext NOT NULL,
  `pageid` bigint(20) NOT NULL DEFAULT '0',
  `extras_post_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `extras_post_id_key` (`extras_post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_ngg_album`
#
INSERT INTO `wp_ngg_album` ( `id`, `name`, `slug`, `previewpic`, `albumdesc`, `sortorder`, `pageid`, `extras_post_id`) VALUES
(1, 'Orchard Painter\'s Cabin', 'orchard-painters-cabin', 0, '', 'W10=', 0, 0) ;

#
# End of data contents of table `wp_ngg_album`
# --------------------------------------------------------



#
# Delete any existing table `wp_ngg_gallery`
#

DROP TABLE IF EXISTS `wp_ngg_gallery`;


#
# Table structure of table `wp_ngg_gallery`
#

CREATE TABLE `wp_ngg_gallery` (
  `gid` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `path` mediumtext,
  `title` mediumtext,
  `galdesc` mediumtext,
  `pageid` bigint(20) NOT NULL DEFAULT '0',
  `previewpic` bigint(20) NOT NULL DEFAULT '0',
  `author` bigint(20) NOT NULL DEFAULT '0',
  `extras_post_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`),
  KEY `extras_post_id_key` (`extras_post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_ngg_gallery`
#
INSERT INTO `wp_ngg_gallery` ( `gid`, `name`, `slug`, `path`, `title`, `galdesc`, `pageid`, `previewpic`, `author`, `extras_post_id`) VALUES
(2, 'orchard-painters-gallery', 'orchard-painters-gallery', '/wp-content/gallery/orchard-painters-gallery', 'Orchard Painter\'s Gallery', 'Orchard Painter\'s Gallery images', 0, 1, 2, 144) ;

#
# End of data contents of table `wp_ngg_gallery`
# --------------------------------------------------------



#
# Delete any existing table `wp_ngg_pictures`
#

DROP TABLE IF EXISTS `wp_ngg_pictures`;


#
# Table structure of table `wp_ngg_pictures`
#

CREATE TABLE `wp_ngg_pictures` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT,
  `image_slug` varchar(255) NOT NULL,
  `post_id` bigint(20) NOT NULL DEFAULT '0',
  `galleryid` bigint(20) NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL,
  `description` mediumtext,
  `alttext` mediumtext,
  `imagedate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `exclude` tinyint(4) DEFAULT '0',
  `sortorder` bigint(20) NOT NULL DEFAULT '0',
  `meta_data` longtext,
  `extras_post_id` bigint(20) NOT NULL DEFAULT '0',
  `updated_at` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`pid`),
  KEY `extras_post_id_key` (`extras_post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_ngg_pictures`
#
INSERT INTO `wp_ngg_pictures` ( `pid`, `image_slug`, `post_id`, `galleryid`, `filename`, `description`, `alttext`, `imagedate`, `exclude`, `sortorder`, `meta_data`, `extras_post_id`, `updated_at`) VALUES
(1, 'cabin1-jpg', 0, 2, 'cabin1.jpg', '', 'cabin1.jpg', '2015-03-14 18:44:25', 0, 0, 'eyJ3aWR0aCI6NTEwLCJoZWlnaHQiOjQwMCwiZnVsbCI6eyJ3aWR0aCI6NTEwLCJoZWlnaHQiOjQwMH0sInRodW1ibmFpbCI6eyJ3aWR0aCI6MTIwLCJoZWlnaHQiOjkwLCJmaWxlbmFtZSI6InRodW1ic19jYWJpbjEuanBnIiwiZ2VuZXJhdGVkIjoiMC4wMDI4OTIwMCAxNDI2MzU4NjY2In0sImFwZXJ0dXJlIjpmYWxzZSwiY3JlZGl0IjpmYWxzZSwiY2FtZXJhIjpmYWxzZSwiY2FwdGlvbiI6ZmFsc2UsImNyZWF0ZWRfdGltZXN0YW1wIjpmYWxzZSwiY29weXJpZ2h0IjpmYWxzZSwiZm9jYWxfbGVuZ3RoIjpmYWxzZSwiaXNvIjpmYWxzZSwic2h1dHRlcl9zcGVlZCI6ZmFsc2UsImZsYXNoIjpmYWxzZSwidGl0bGUiOmZhbHNlLCJrZXl3b3JkcyI6ZmFsc2UsInNhdmVkIjp0cnVlLCJuZ2cwZHluLTM1MHgzNTAtMDBmMHcwMTBjMDEwcjExMGYxMTByMDEwdDAxMCI6eyJ3aWR0aCI6MzUwLCJoZWlnaHQiOjI3NSwiZmlsZW5hbWUiOiJjYWJpbjEuanBnLW5nZ2lkMDExLW5nZzBkeW4tMzUweDM1MC0wMGYwdzAxMGMwMTByMTEwZjExMHIwMTB0MDEwLmpwZyIsImdlbmVyYXRlZCI6IjAuNzE1NjIxMDAgMTQyNjM1ODcwOSJ9fQ==', 143, 1426358725),
(2, 'cabin2-jpg', 0, 2, 'cabin2.jpg', '', 'cabin2.jpg', '2015-03-14 18:44:26', 0, 0, 'eyJ3aWR0aCI6MzEwLCJoZWlnaHQiOjQwMCwiZnVsbCI6eyJ3aWR0aCI6MzEwLCJoZWlnaHQiOjQwMH0sInRodW1ibmFpbCI6eyJ3aWR0aCI6MTIwLCJoZWlnaHQiOjkwLCJmaWxlbmFtZSI6InRodW1ic19jYWJpbjIuanBnIiwiZ2VuZXJhdGVkIjoiMC41MzY4NjEwMCAxNDI2MzU4NjY2In0sImFwZXJ0dXJlIjpmYWxzZSwiY3JlZGl0IjpmYWxzZSwiY2FtZXJhIjpmYWxzZSwiY2FwdGlvbiI6ZmFsc2UsImNyZWF0ZWRfdGltZXN0YW1wIjpmYWxzZSwiY29weXJpZ2h0IjpmYWxzZSwiZm9jYWxfbGVuZ3RoIjpmYWxzZSwiaXNvIjpmYWxzZSwic2h1dHRlcl9zcGVlZCI6ZmFsc2UsImZsYXNoIjpmYWxzZSwidGl0bGUiOmZhbHNlLCJrZXl3b3JkcyI6ZmFsc2UsInNhdmVkIjp0cnVlfQ==', 146, 1426358725),
(3, 'cabin3-jpg', 0, 2, 'cabin3.jpg', '', 'cabin3.jpg', '2015-03-14 18:44:26', 0, 0, 'eyJ3aWR0aCI6MzEwLCJoZWlnaHQiOjQwMCwiZnVsbCI6eyJ3aWR0aCI6MzEwLCJoZWlnaHQiOjQwMH0sInRodW1ibmFpbCI6eyJ3aWR0aCI6MTIwLCJoZWlnaHQiOjkwLCJmaWxlbmFtZSI6InRodW1ic19jYWJpbjMuanBnIiwiZ2VuZXJhdGVkIjoiMC4wMzA5MDgwMCAxNDI2MzU4NjY3In0sImFwZXJ0dXJlIjpmYWxzZSwiY3JlZGl0IjpmYWxzZSwiY2FtZXJhIjpmYWxzZSwiY2FwdGlvbiI6ZmFsc2UsImNyZWF0ZWRfdGltZXN0YW1wIjpmYWxzZSwiY29weXJpZ2h0IjpmYWxzZSwiZm9jYWxfbGVuZ3RoIjpmYWxzZSwiaXNvIjpmYWxzZSwic2h1dHRlcl9zcGVlZCI6ZmFsc2UsImZsYXNoIjpmYWxzZSwidGl0bGUiOmZhbHNlLCJrZXl3b3JkcyI6ZmFsc2UsInNhdmVkIjp0cnVlfQ==', 148, 1426358725) ;

#
# End of data contents of table `wp_ngg_pictures`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=807 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://sanctuary.lisawolfsonmyers.com', 'yes'),
(2, 'home', 'http://sanctuary.lisawolfsonmyers.com', 'yes'),
(3, 'blogname', 'Sanctuary', 'yes'),
(4, 'blogdescription', 'ECO-RETREAT for PROFESSIONAL ARTISTS', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'lwolfson@mcad.edu', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '', 'yes'),
(11, 'comments_notify', '', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'closed', 'yes'),
(20, 'default_ping_status', 'closed', 'yes'),
(21, 'default_pingback_flag', '', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '', 'yes'),
(27, 'moderation_notify', '', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'gzipcompression', '0', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:7:{i:0;s:31:"acf-button-field/acf-button.php";i:1;s:30:"advanced-custom-fields/acf.php";i:2;s:23:"developer/developer.php";i:3;s:33:"monster-widget/monster-widget.php";i:4;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";i:5;s:39:"slideshow-gallery/slideshow-gallery.php";i:6;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'advanced_edit', '0', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '0', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', 'a:2:{i:0;s:87:"/home2/lwolfson/public_html/sanctuary/wp-content/plugins/advanced-custom-fields/acf.php";i:1;s:0:"";}', 'no'),
(41, 'template', 'sanctuary', 'yes'),
(42, 'stylesheet', 'sanctuary', 'yes'),
(43, 'comment_whitelist', '', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'subscriber', 'yes'),
(49, 'db_version', '30133', 'yes'),
(50, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '0', 'yes'),
(53, 'default_link_category', '2', 'yes'),
(54, 'show_on_front', 'page', 'yes'),
(55, 'tag_base', '', 'yes'),
(56, 'show_avatars', '', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '150', 'yes'),
(60, 'thumbnail_size_h', '150', 'yes'),
(61, 'thumbnail_crop', '1', 'yes'),
(62, 'medium_size_w', '300', 'yes'),
(63, 'medium_size_h', '300', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '1024', 'yes'),
(66, 'large_size_h', '1024', 'yes'),
(67, 'image_default_link_type', 'file', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:0:{}', 'yes'),
(79, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_text', 'a:0:{}', 'yes'),
(81, 'widget_rss', 'a:0:{}', 'yes'),
(82, 'uninstall_plugins', 'a:0:{}', 'no'),
(83, 'timezone_string', '', 'yes'),
(84, 'page_for_posts', '20', 'yes'),
(85, 'page_on_front', '27', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'initial_db_version', '30133', 'yes'),
(89, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:77:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:24:"NextGEN Gallery overview";b:1;s:19:"NextGEN Use TinyMCE";b:1;s:21:"NextGEN Upload images";b:1;s:22:"NextGEN Manage gallery";b:1;s:19:"NextGEN Manage tags";b:1;s:29:"NextGEN Manage others gallery";b:1;s:18:"NextGEN Edit album";b:1;s:20:"NextGEN Change style";b:1;s:22:"NextGEN Change options";b:1;s:24:"NextGEN Attach Interface";b:1;s:17:"slideshow_welcome";b:1;s:15:"slideshow_about";b:1;s:16:"slideshow_slides";b:1;s:19:"slideshow_galleries";b:1;s:18:"slideshow_settings";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(90, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(91, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(92, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(96, 'cron', 'a:11:{i:1426402860;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1426405939;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1426445303;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1426449210;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1426964134;a:1:{s:24:"slideshow_ratereviewhook";a:1:{s:32:"d63aca0b7e6237c7964320bd7fc95644";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:7;}}}}i:1427568934;a:1:{s:24:"slideshow_ratereviewhook";a:1:{s:32:"78525e41f5c2848ff7e1a2337fb96361";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:14;}}}}i:1428951334;a:1:{s:24:"slideshow_ratereviewhook";a:1:{s:32:"b81956e4bb4ba571b1678549dbe90e2a";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:30;}}}}i:1431543334;a:1:{s:24:"slideshow_ratereviewhook";a:1:{s:32:"1f2017e1ed51c7e11ca55ed0583ac79c";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:60;}}}}i:1441911334;a:1:{s:24:"slideshow_ratereviewhook";a:1:{s:32:"b058f96ad617d118dc656b8b440ccdb0";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:180;}}}}i:1457463334;a:1:{s:24:"slideshow_ratereviewhook";a:1:{s:32:"32a99f765d2b1a63b1790ee770c3fb21";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:360;}}}}s:7:"version";i:2;}', 'yes'),
(105, 'auth_key', ' &!aCwRO]h#|1iP%ZIrd=uG{yVqio50&!d4BR+yqy{;J7U,tXh.DdKMI3{tCHya{', 'yes'),
(106, 'auth_salt', '<W>FstC8%!aswG)qp.<xy+i <<M}p[i1^fHnmTew)o:Ki=@IC4yJ?H4cq$S@fx+>', 'yes'),
(107, 'logged_in_key', '3g7p>?Y^uK!u,G[J<4:UfHojhsax}poihff12EMLk;%fJ3K^=c}#S6(z?k68&veG', 'yes'),
(108, 'logged_in_salt', 'We/k7erDHiVYH4_{;M]uq1)iX51~:5=0yF4q2l1wPi4%Htk2^2FeF;W-~]Se?F%2', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(109, 'nonce_key', ')WMV:<QeNPWq!N>sH`.7gI&*>IZI5G2NpH9J=Ef)O15/M8+oFmG>ftlYW?{OGtob', 'yes'),
(110, 'nonce_salt', '+k.On7`)]b 8SPZbNKS(%d@y0vz(1gk R~bw-AMfX?<+NCxs&EK?ktuSpe{Fww}j', 'yes'),
(113, 'can_compress_scripts', '1', 'yes'),
(132, 'current_theme', 'Sanctuary', 'yes'),
(133, 'theme_mods_sanctuary', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:6:"social";i:6;s:7:"primary";i:4;}}', 'yes'),
(134, 'theme_switched', '', 'yes'),
(141, 'recently_activated', 'a:4:{s:29:"nextgen-gallery/nggallery.php";i:1426359291;s:69:"advanced-custom-fields-nextgen-gallery-custom-field/acf-nggallery.php";i:1426359281;s:23:"slider-image/slider.php";i:1425842035;s:23:"ml-slider/ml-slider.php";i:1425841353;}', 'yes'),
(142, 'acf_version', '4.4.0', 'yes'),
(158, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:17:"lwolfson@mcad.edu";s:7:"version";s:5:"4.1.1";s:9:"timestamp";i:1424372545;}', 'yes'),
(210, 'a8c_developer', 'a:1:{s:12:"project_type";s:11:"wporg-theme";}', 'yes'),
(323, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(352, 'WPLANG', '', 'yes'),
(371, 'metaslider_systemcheck', 'a:2:{s:16:"wordPressVersion";b:0;s:12:"imageLibrary";b:0;}', 'yes'),
(372, 'ml-slider_children', 'a:0:{}', 'yes'),
(396, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1425839740;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:0:{}}}}', 'yes'),
(397, 'theme_mods_twentyfourteen', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1425839754;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:0:{}s:9:"sidebar-2";N;s:9:"sidebar-3";N;}}}', 'yes'),
(559, 'category_children', 'a:0:{}', 'yes'),
(605, 'ngg_doing_upgrade', '', 'yes'),
(606, 'photocrati_auto_update_admin_update_list', '', 'yes'),
(607, 'photocrati_auto_update_admin_check_date', '', 'yes'),
(608, 'ngg_db_version', '1.8.1', 'yes'),
(609, 'ngg_options', 'a:85:{s:22:"router_param_separator";s:2:"--";s:19:"router_param_prefix";s:0:"";s:17:"router_param_slug";s:9:"nggallery";s:11:"gallerypath";s:19:"wp-content/gallery/";s:11:"wpmuCSSfile";s:13:"nggallery.css";s:9:"wpmuStyle";b:0;s:9:"wpmuRoles";b:0;s:16:"wpmuImportFolder";b:0;s:13:"wpmuZipUpload";b:0;s:14:"wpmuQuotaCheck";b:0;s:17:"datamapper_driver";s:22:"custom_post_datamapper";s:21:"gallerystorage_driver";s:25:"ngglegacy_gallery_storage";s:20:"maximum_entity_count";i:500;s:9:"deleteImg";b:1;s:9:"swfUpload";b:1;s:13:"usePermalinks";b:0;s:13:"permalinkSlug";s:9:"nggallery";s:14:"graphicLibrary";s:2:"gd";s:14:"imageMagickDir";s:15:"/usr/local/bin/";s:11:"useMediaRSS";b:0;s:18:"galleries_in_feeds";b:0;s:12:"activateTags";i:0;s:10:"appendType";s:4:"tags";s:9:"maxImages";i:7;s:14:"relatedHeading";s:24:"<h3>Related Images:</h3>";s:10:"thumbwidth";i:120;s:11:"thumbheight";i:90;s:8:"thumbfix";b:1;s:12:"thumbquality";i:100;s:8:"imgWidth";i:800;s:9:"imgHeight";i:600;s:10:"imgQuality";i:100;s:9:"imgBackup";b:1;s:13:"imgAutoResize";b:0;s:9:"galImages";s:2:"20";s:17:"galPagedGalleries";i:0;s:10:"galColumns";i:0;s:12:"galShowSlide";b:1;s:12:"galTextSlide";s:16:"[Show slideshow]";s:14:"galTextGallery";s:17:"[Show thumbnails]";s:12:"galShowOrder";s:7:"gallery";s:7:"galSort";s:9:"sortorder";s:10:"galSortDir";s:3:"ASC";s:10:"galNoPages";b:1;s:13:"galImgBrowser";i:0;s:12:"galHiddenImg";i:0;s:10:"galAjaxNav";i:0;s:11:"thumbEffect";s:8:"fancybox";s:9:"thumbCode";s:41:"class="ngg-fancybox" rel="%GALLERY_NAME%"";s:18:"thumbEffectContext";s:14:"nextgen_images";s:5:"wmPos";s:8:"botRight";s:6:"wmXpos";i:5;s:6:"wmYpos";i:5;s:6:"wmType";i:0;s:6:"wmPath";s:0:"";s:6:"wmFont";s:9:"arial.ttf";s:6:"wmSize";i:10;s:6:"wmText";s:9:"Sanctuary";s:7:"wmColor";s:6:"000000";s:8:"wmOpaque";s:3:"100";s:8:"enableIR";i:0;s:7:"slideFx";s:4:"fade";s:5:"irURL";s:0:"";s:12:"irXHTMLvalid";i:0;s:7:"irAudio";s:0:"";s:7:"irWidth";i:600;s:8:"irHeight";i:400;s:9:"irShuffle";b:1;s:17:"irLinkfromdisplay";b:1;s:16:"irShownavigation";i:0;s:11:"irShowicons";i:0;s:11:"irWatermark";i:0;s:13:"irOverstretch";s:4:"True";s:12:"irRotatetime";i:10;s:12:"irTransition";s:6:"random";s:10:"irKenburns";i:0;s:11:"irBackcolor";s:6:"000000";s:12:"irFrontcolor";s:6:"FFFFFF";s:12:"irLightcolor";s:6:"CC0000";s:13:"irScreencolor";s:6:"000000";s:11:"activateCSS";i:1;s:7:"CSSfile";s:13:"nggallery.css";s:22:"dynamic_thumbnail_slug";s:13:"nextgen-image";s:11:"installDate";i:1426358507;s:23:"dynamic_stylesheet_slug";s:12:"nextgen-dcss";}', 'yes'),
(610, 'pope_module_list', 'a:32:{i:0;s:17:"photocrati-fs|0.4";i:1;s:19:"photocrati-i18n|0.1";i:2;s:25:"photocrati-validation|0.1";i:3;s:21:"photocrati-router|0.7";i:4;s:32:"photocrati-wordpress_routing|0.6";i:5;s:23:"photocrati-security|0.2";i:6;s:31:"photocrati-nextgen_settings|0.8";i:7;s:18:"photocrati-mvc|0.5";i:8;s:19:"photocrati-ajax|0.8";i:9;s:25:"photocrati-datamapper|0.8";i:10;s:30:"photocrati-nextgen-legacy|0.14";i:11;s:28:"photocrati-nextgen-data|0.10";i:12;s:33:"photocrati-dynamic_thumbnails|0.6";i:13;s:28:"photocrati-nextgen_admin|0.9";i:14;s:39:"photocrati-nextgen_gallery_display|0.13";i:15;s:34:"photocrati-frame_communication|0.4";i:16;s:30:"photocrati-attach_to_post|0.11";i:17;s:38:"photocrati-nextgen_addgallery_page|0.6";i:18;s:36:"photocrati-nextgen_other_options|0.8";i:19;s:33:"photocrati-nextgen_pagination|0.3";i:20;s:34:"photocrati-nextgen_pro_upgrade|0.4";i:21;s:20:"photocrati-cache|0.2";i:22;s:24:"photocrati-lightbox|0.14";i:23;s:38:"photocrati-nextgen_basic_templates|0.5";i:24;s:37:"photocrati-nextgen_basic_gallery|0.13";i:25;s:42:"photocrati-nextgen_basic_imagebrowser|0.10";i:26;s:39:"photocrati-nextgen_basic_singlepic|0.11";i:27;s:38:"photocrati-nextgen_basic_tagcloud|0.11";i:28;s:35:"photocrati-nextgen_basic_album|0.10";i:29;s:21:"photocrati-widget|0.5";i:30;s:33:"photocrati-third_party_compat|0.4";i:31;s:29:"photocrati-nextgen_xmlrpc|0.4";}', 'yes'),
(733, 'MVC_tracker', 'a:1:{i:1426358926;a:3:{i:0;s:19:"find_static_abspath";i:1;s:14:"get_static_url";i:2;s:14:"get_static_url";}}', 'no'),
(737, 'Galleryversion', '1.5.3', 'yes'),
(738, 'Gallerypermissions', 'a:1:{s:13:"administrator";a:5:{i:0;s:7:"welcome";i:1;s:5:"about";i:2;s:6:"slides";i:3;s:9:"galleries";i:4;s:8:"settings";}}', 'yes'),
(739, 'Galleryexisting', '1', 'yes'),
(740, 'Galleryresizeimagescrop', 'Y', 'yes'),
(741, 'Galleryimagespath', 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/slideshow-gallery/', 'yes'),
(742, 'Gallerystyles', 'a:11:{s:6:"layout";s:8:"specific";s:9:"resheight";s:2:"50";s:13:"resheighttype";s:1:"%";s:12:"resizeimages";s:1:"N";s:5:"width";s:3:"510";s:6:"height";s:3:"460";s:6:"border";s:0:"";s:10:"background";s:7:"#ffffff";s:14:"infobackground";s:7:"#000000";s:9:"infocolor";s:7:"#ffffff";s:11:"thumbactive";s:7:"#ffffff";}', 'yes'),
(743, 'Galleryeffect', 'fade', 'yes'),
(744, 'Galleryeasing', 'swing', 'yes'),
(745, 'Galleryslide_direction', 'lr', 'yes'),
(746, 'Galleryfadespeed', '10', 'yes'),
(747, 'Galleryshownav', 'N', 'yes'),
(748, 'Gallerynavopacity', '25', 'yes'),
(749, 'Gallerynavhover', '75', 'yes'),
(750, 'Galleryinformation', 'N', 'yes'),
(751, 'Galleryinfospeed', '10', 'yes'),
(753, 'Gallerythumbnails', 'Y', 'yes'),
(754, 'Gallerythumbwidth', '52', 'yes'),
(755, 'Gallerythumbheight', '52', 'yes'),
(756, 'Gallerythumbposition', 'bottom', 'yes'),
(757, 'Gallerythumbopacity', '100', 'yes'),
(758, 'Gallerythumbscrollspeed', '5', 'yes'),
(759, 'Gallerythumbspacing', '15', 'yes'),
(760, 'Gallerythumbactive', '#FFFFFF', 'yes'),
(761, 'Galleryautoslide', 'Y', 'yes'),
(762, 'Galleryautospeed', '5', 'yes'),
(763, 'Galleryalwaysauto', 'false', 'yes'),
(764, 'Galleryimagesthickbox', 'N', 'yes'),
(765, 'Galleryjsoutput', 'perslideshow', 'yes'),
(766, 'Galleryratereview_scheduled', '1', 'yes'),
(768, 'Gallerysave', 'Save Configuration', 'yes'),
(794, 'rewrite_rules', 'a:82:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:41:"studio-cabins/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:51:"studio-cabins/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:71:"studio-cabins/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"studio-cabins/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"studio-cabins/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:34:"studio-cabins/([^/]+)/trackback/?$";s:32:"index.php?cabin=$matches[1]&tb=1";s:42:"studio-cabins/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?cabin=$matches[1]&paged=$matches[2]";s:49:"studio-cabins/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?cabin=$matches[1]&cpage=$matches[2]";s:34:"studio-cabins/([^/]+)(/[0-9]+)?/?$";s:44:"index.php?cabin=$matches[1]&page=$matches[2]";s:30:"studio-cabins/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:40:"studio-cabins/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:60:"studio-cabins/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"studio-cabins/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"studio-cabins/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=27&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes'),
(798, 'Galleryinfohideonmobile', '1', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1219 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_edit_last', '1'),
(3, 4, '_edit_lock', '1425494773:1'),
(4, 4, '_wp_trash_meta_status', 'publish'),
(5, 4, '_wp_trash_meta_time', '1425498340'),
(6, 2, '_edit_lock', '1425832326:1'),
(7, 2, '_edit_last', '1'),
(26, 10, '_menu_item_type', 'custom'),
(27, 10, '_menu_item_menu_item_parent', '0'),
(28, 10, '_menu_item_object_id', '10'),
(29, 10, '_menu_item_object', 'custom'),
(30, 10, '_menu_item_target', ''),
(31, 10, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(32, 10, '_menu_item_xfn', ''),
(33, 10, '_menu_item_url', 'http://sanctuary.lisawolfsonmyers.com/'),
(34, 10, '_menu_item_orphaned', '1425746166'),
(35, 11, '_menu_item_type', 'post_type'),
(36, 11, '_menu_item_menu_item_parent', '0'),
(37, 11, '_menu_item_object_id', '2'),
(38, 11, '_menu_item_object', 'page'),
(39, 11, '_menu_item_target', ''),
(40, 11, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(41, 11, '_menu_item_xfn', ''),
(42, 11, '_menu_item_url', ''),
(43, 11, '_menu_item_orphaned', '1425746166'),
(44, 12, '_menu_item_type', 'custom'),
(45, 12, '_menu_item_menu_item_parent', '0'),
(46, 12, '_menu_item_object_id', '12'),
(47, 12, '_menu_item_object', 'custom'),
(48, 12, '_menu_item_target', ''),
(49, 12, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(50, 12, '_menu_item_xfn', ''),
(51, 12, '_menu_item_url', 'http://sanctuary.lisawolfsonmyers.com/'),
(52, 12, '_menu_item_orphaned', '1425746223'),
(53, 13, '_menu_item_type', 'post_type'),
(54, 13, '_menu_item_menu_item_parent', '0'),
(55, 13, '_menu_item_object_id', '2'),
(56, 13, '_menu_item_object', 'page'),
(57, 13, '_menu_item_target', ''),
(58, 13, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(59, 13, '_menu_item_xfn', ''),
(60, 13, '_menu_item_url', ''),
(61, 13, '_menu_item_orphaned', '1425746223'),
(62, 16, '_edit_last', '1'),
(63, 16, '_edit_lock', '1425746238:1'),
(64, 18, '_edit_last', '1'),
(65, 18, '_edit_lock', '1425746252:1'),
(66, 20, '_edit_last', '1'),
(67, 20, '_edit_lock', '1425825406:1'),
(68, 22, '_edit_last', '1'),
(69, 22, '_edit_lock', '1425746273:1'),
(70, 24, '_edit_last', '1'),
(71, 24, '_edit_lock', '1425827837:1'),
(72, 27, '_edit_last', '1'),
(73, 27, '_edit_lock', '1426187096:2'),
(74, 29, '_menu_item_type', 'custom'),
(75, 29, '_menu_item_menu_item_parent', '0'),
(76, 29, '_menu_item_object_id', '29'),
(77, 29, '_menu_item_object', 'custom'),
(78, 29, '_menu_item_target', ''),
(79, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(80, 29, '_menu_item_xfn', ''),
(81, 29, '_menu_item_url', 'http://sanctuary.lisawolfsonmyers.com/'),
(82, 29, '_menu_item_orphaned', '1425746520'),
(83, 30, '_menu_item_type', 'post_type'),
(84, 30, '_menu_item_menu_item_parent', '0'),
(85, 30, '_menu_item_object_id', '24'),
(86, 30, '_menu_item_object', 'page'),
(87, 30, '_menu_item_target', ''),
(88, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(89, 30, '_menu_item_xfn', ''),
(90, 30, '_menu_item_url', ''),
(92, 31, '_menu_item_type', 'post_type'),
(93, 31, '_menu_item_menu_item_parent', '0'),
(94, 31, '_menu_item_object_id', '16'),
(95, 31, '_menu_item_object', 'page'),
(96, 31, '_menu_item_target', ''),
(97, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(98, 31, '_menu_item_xfn', ''),
(99, 31, '_menu_item_url', ''),
(101, 32, '_menu_item_type', 'post_type'),
(102, 32, '_menu_item_menu_item_parent', '0'),
(103, 32, '_menu_item_object_id', '20'),
(104, 32, '_menu_item_object', 'page'),
(105, 32, '_menu_item_target', ''),
(106, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(107, 32, '_menu_item_xfn', ''),
(108, 32, '_menu_item_url', ''),
(110, 33, '_menu_item_type', 'post_type'),
(111, 33, '_menu_item_menu_item_parent', '0'),
(112, 33, '_menu_item_object_id', '27'),
(113, 33, '_menu_item_object', 'page'),
(114, 33, '_menu_item_target', ''),
(115, 33, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(116, 33, '_menu_item_xfn', ''),
(117, 33, '_menu_item_url', ''),
(118, 33, '_menu_item_orphaned', '1425746520'),
(119, 34, '_menu_item_type', 'post_type'),
(120, 34, '_menu_item_menu_item_parent', '0'),
(121, 34, '_menu_item_object_id', '22') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(122, 34, '_menu_item_object', 'page'),
(123, 34, '_menu_item_target', ''),
(124, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(125, 34, '_menu_item_xfn', ''),
(126, 34, '_menu_item_url', ''),
(128, 35, '_menu_item_type', 'post_type'),
(129, 35, '_menu_item_menu_item_parent', '0'),
(130, 35, '_menu_item_object_id', '18'),
(131, 35, '_menu_item_object', 'page'),
(132, 35, '_menu_item_target', ''),
(133, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(134, 35, '_menu_item_xfn', ''),
(135, 35, '_menu_item_url', ''),
(137, 36, '_menu_item_type', 'post_type'),
(138, 36, '_menu_item_menu_item_parent', '0'),
(139, 36, '_menu_item_object_id', '2'),
(140, 36, '_menu_item_object', 'page'),
(141, 36, '_menu_item_target', ''),
(142, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(143, 36, '_menu_item_xfn', ''),
(144, 36, '_menu_item_url', ''),
(149, 1, '_wp_trash_meta_status', 'publish'),
(150, 1, '_wp_trash_meta_time', '1425832643'),
(151, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:5:"trash";}'),
(152, 43, 'ml-slider_settings', 'a:35:{s:4:"type";s:4:"flex";s:6:"random";s:5:"false";s:8:"cssClass";s:0:"";s:8:"printCss";s:4:"true";s:7:"printJs";s:4:"true";s:5:"width";s:3:"960";s:6:"height";s:3:"864";s:3:"spw";s:1:"7";s:3:"sph";s:1:"5";s:5:"delay";s:4:"3000";s:6:"sDelay";i:30;s:7:"opacity";d:0.6999999999999999555910790149937383830547332763671875;s:10:"titleSpeed";i:500;s:6:"effect";s:5:"slide";s:10:"navigation";s:5:"false";s:5:"links";s:5:"false";s:10:"hoverPause";s:5:"false";s:5:"theme";s:7:"default";s:9:"direction";s:10:"horizontal";s:7:"reverse";s:5:"false";s:14:"animationSpeed";s:3:"600";s:8:"prevText";s:1:"<";s:8:"nextText";s:1:">";s:6:"slices";s:2:"15";s:6:"center";s:4:"true";s:9:"smartCrop";s:4:"true";s:12:"carouselMode";s:5:"false";s:14:"carouselMargin";s:1:"5";s:6:"easing";s:6:"linear";s:8:"autoPlay";s:4:"true";s:11:"thumb_width";i:150;s:12:"thumb_height";i:100;s:9:"fullWidth";s:5:"false";s:10:"noConflict";s:5:"false";s:12:"smoothHeight";s:5:"false";}'),
(153, 44, '_wp_attached_file', '2015/03/homepage1.jpg'),
(154, 44, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:960;s:6:"height";i:864;s:4:"file";s:21:"2015/03/homepage1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"homepage1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"homepage1-300x270.jpg";s:5:"width";i:300;s:6:"height";i:270;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(155, 45, '_wp_attached_file', '2015/03/homepage2.jpg'),
(156, 45, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:960;s:6:"height";i:864;s:4:"file";s:21:"2015/03/homepage2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"homepage2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"homepage2-300x270.jpg";s:5:"width";i:300;s:6:"height";i:270;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(157, 46, '_wp_attached_file', '2015/03/homepage3.jpg'),
(158, 46, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:960;s:6:"height";i:864;s:4:"file";s:21:"2015/03/homepage3.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"homepage3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"homepage3-300x270.jpg";s:5:"width";i:300;s:6:"height";i:270;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(159, 47, '_wp_attached_file', '2015/03/homepage4.jpg'),
(160, 47, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:960;s:6:"height";i:724;s:4:"file";s:21:"2015/03/homepage4.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"homepage4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"homepage4-300x226.jpg";s:5:"width";i:300;s:6:"height";i:226;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(161, 48, '_wp_attached_file', '2015/03/homepage5.jpg'),
(162, 48, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:960;s:6:"height";i:724;s:4:"file";s:21:"2015/03/homepage5.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"homepage5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"homepage5-300x226.jpg";s:5:"width";i:300;s:6:"height";i:226;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(163, 44, '_wp_attachment_image_alt', 'Image of an artist cabin'),
(164, 45, '_wp_attachment_image_alt', 'Image of a waterfall'),
(165, 46, '_wp_attachment_image_alt', 'Inside of an artist cabin'),
(166, 47, '_wp_attachment_image_alt', 'Plate of organic food'),
(167, 48, '_wp_attachment_image_alt', 'Band playing'),
(168, 48, 'ml-slider_type', 'image'),
(169, 47, 'ml-slider_type', 'image'),
(170, 46, 'ml-slider_type', 'image'),
(171, 45, 'ml-slider_type', 'image'),
(172, 44, 'ml-slider_type', 'image'),
(173, 48, '_wp_attachment_backup_sizes', 'a:2:{s:15:"resized-700x300";a:5:{s:4:"path";s:86:"/home2/lwolfson/public_html/sanctuary/wp-content/uploads/2015/03/homepage5-700x300.jpg";s:4:"file";s:21:"homepage5-700x300.jpg";s:5:"width";i:700;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:15:"resized-804x724";a:5:{s:4:"path";s:86:"/home2/lwolfson/public_html/sanctuary/wp-content/uploads/2015/03/homepage5-804x724.jpg";s:4:"file";s:21:"homepage5-804x724.jpg";s:5:"width";i:804;s:6:"height";i:724;s:9:"mime-type";s:10:"image/jpeg";}}'),
(174, 47, '_wp_attachment_backup_sizes', 'a:2:{s:15:"resized-700x300";a:5:{s:4:"path";s:86:"/home2/lwolfson/public_html/sanctuary/wp-content/uploads/2015/03/homepage4-700x300.jpg";s:4:"file";s:21:"homepage4-700x300.jpg";s:5:"width";i:700;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:15:"resized-804x724";a:5:{s:4:"path";s:86:"/home2/lwolfson/public_html/sanctuary/wp-content/uploads/2015/03/homepage4-804x724.jpg";s:4:"file";s:21:"homepage4-804x724.jpg";s:5:"width";i:804;s:6:"height";i:724;s:9:"mime-type";s:10:"image/jpeg";}}'),
(175, 46, '_wp_attachment_backup_sizes', 'a:1:{s:15:"resized-700x300";a:5:{s:4:"path";s:86:"/home2/lwolfson/public_html/sanctuary/wp-content/uploads/2015/03/homepage3-700x300.jpg";s:4:"file";s:21:"homepage3-700x300.jpg";s:5:"width";i:700;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}'),
(176, 45, '_wp_attachment_backup_sizes', 'a:1:{s:15:"resized-700x300";a:5:{s:4:"path";s:86:"/home2/lwolfson/public_html/sanctuary/wp-content/uploads/2015/03/homepage2-700x300.jpg";s:4:"file";s:21:"homepage2-700x300.jpg";s:5:"width";i:700;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}'),
(177, 44, '_wp_attachment_backup_sizes', 'a:1:{s:15:"resized-700x300";a:5:{s:4:"path";s:86:"/home2/lwolfson/public_html/sanctuary/wp-content/uploads/2015/03/homepage1-700x300.jpg";s:4:"file";s:21:"homepage1-700x300.jpg";s:5:"width";i:700;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}'),
(178, 44, 'ml-slider_crop_position', 'center-center'),
(179, 48, 'ml-slider_crop_position', 'center-center'),
(180, 47, 'ml-slider_crop_position', 'center-center'),
(181, 46, 'ml-slider_crop_position', 'center-center'),
(182, 45, 'ml-slider_crop_position', 'center-center'),
(183, 53, '_edit_last', '1'),
(185, 53, 'position', 'normal'),
(186, 53, 'layout', 'no_box'),
(187, 53, 'hide_on_screen', ''),
(188, 53, '_edit_lock', '1426187723:2'),
(189, 53, 'field_54fca1a0d31ea', 'a:11:{s:3:"key";s:19:"field_54fca1a0d31ea";s:5:"label";s:8:"Image #1";s:4:"name";s:25:"homepage-carousel-image-1";s:4:"type";s:5:"image";s:12:"instructions";s:37:"Upload images that are 960px by 864px";s:8:"required";s:1:"0";s:11:"save_format";s:2:"id";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(190, 53, 'field_54fca260d31eb', 'a:14:{s:3:"key";s:19:"field_54fca260d31eb";s:5:"label";s:23:"Caption #1 - first line";s:4:"name";s:27:"homepage-carousel-caption-1";s:4:"type";s:4:"text";s:12:"instructions";s:8:"Optional";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(193, 53, 'field_54fca2b85a09e', 'a:11:{s:3:"key";s:19:"field_54fca2b85a09e";s:5:"label";s:8:"Image #2";s:4:"name";s:25:"homepage-carousel-image-2";s:4:"type";s:5:"image";s:12:"instructions";s:37:"Upload images that are 960px by 864px";s:8:"required";s:1:"0";s:11:"save_format";s:2:"id";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}'),
(194, 53, 'field_54fca2df5a09f', 'a:14:{s:3:"key";s:19:"field_54fca2df5a09f";s:5:"label";s:23:"Caption #2 - first line";s:4:"name";s:27:"homepage-carousel-caption-2";s:4:"type";s:4:"text";s:12:"instructions";s:8:"Optional";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}'),
(198, 53, 'field_54fca347d22f1', 'a:11:{s:3:"key";s:19:"field_54fca347d22f1";s:5:"label";s:31:"Randomize Carousel Presentation";s:4:"name";s:37:"homepage-random-carousel-presentation";s:4:"type";s:8:"checkbox";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:7:"choices";a:1:{s:3:"yes";s:66:"Check this box to randomize the order of the images in the slider.";}s:13:"default_value";s:0:"";s:6:"layout";s:8:"vertical";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:15;}'),
(214, 27, 'homepage-slider-image-1', '44'),
(215, 27, '_homepage-slider-image-1', 'field_54fca1a0d31ea'),
(216, 27, 'homepage-slider-image-2', '46'),
(217, 27, '_homepage-slider-image-2', 'field_54fca2b85a09e'),
(218, 27, 'homepage-slider-caption-1', 'A place to work without distraction'),
(219, 27, '_homepage-slider-caption-1', 'field_54fca260d31eb'),
(220, 27, 'homepage-slider-caption-2', 'WORK/LIVE STUDIO CABINS designed for specific art-practices'),
(221, 27, '_homepage-slider-caption-2', 'field_54fca2df5a09f'),
(222, 27, 'homepage-slider-url-1', ''),
(223, 27, '_homepage-slider-url-1', 'field_54fca28dd31ec'),
(224, 27, 'homepage-slider-url-2', ''),
(225, 27, '_homepage-slider-url-2', 'field_54fca2f85a0a0'),
(226, 27, 'homepage-slider-random-presentation', ''),
(227, 27, '_homepage-slider-random-presentation', 'field_54fca347d22f1'),
(245, 27, 'theme-header-carousel-image-1', '44'),
(246, 27, '_theme-header-carousel-image-1', 'field_54fca1a0d31ea'),
(247, 27, 'theme-header-carousel-image-2', '46'),
(248, 27, '_theme-header-carousel-image-2', 'field_54fca2b85a09e'),
(249, 27, 'theme-header-carousel-caption-1', 'A place to work'),
(250, 27, '_theme-header-carousel-caption-1', 'field_54fca260d31eb'),
(251, 27, 'theme-header-carousel-image-1caption-2', 'Work/live studio cabins'),
(252, 27, '_theme-header-carousel-image-1caption-2', 'field_54fca2df5a09f'),
(253, 27, 'theme-header-carousel-url-1', ''),
(254, 27, '_theme-header-carousel-url-1', 'field_54fcafdc06c57'),
(255, 27, 'theme-header-carousel-url-2', ''),
(256, 27, '_theme-header-carousel-url-2', 'field_54fca2f85a0a0'),
(257, 27, 'theme-header-random-carousel-presentation', ''),
(258, 27, '_theme-header-random-carousel-presentation', 'field_54fca347d22f1'),
(259, 53, 'field_54fcbc341a851', 'a:11:{s:3:"key";s:19:"field_54fcbc341a851";s:5:"label";s:8:"Image #3";s:4:"name";s:25:"homepage-carousel-image-3";s:4:"type";s:5:"image";s:12:"instructions";s:37:"Upload images that are 960px by 864px";s:8:"required";s:1:"0";s:11:"save_format";s:2:"id";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:6;}'),
(260, 53, 'field_54fcbc5c1a852', 'a:11:{s:3:"key";s:19:"field_54fcbc5c1a852";s:5:"label";s:8:"Image #4";s:4:"name";s:25:"homepage-carousel-image-4";s:4:"type";s:5:"image";s:12:"instructions";s:37:"Upload images that are 960px by 864px";s:8:"required";s:1:"0";s:11:"save_format";s:2:"id";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:9;}'),
(261, 53, 'field_54fcbc6d1a853', 'a:11:{s:3:"key";s:19:"field_54fcbc6d1a853";s:5:"label";s:8:"Image #5";s:4:"name";s:25:"homepage-carousel-image-5";s:4:"type";s:5:"image";s:12:"instructions";s:37:"Upload images that are 960px by 864px";s:8:"required";s:1:"0";s:11:"save_format";s:2:"id";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:12;}'),
(262, 53, 'field_54fcbc8f1a854', 'a:14:{s:3:"key";s:19:"field_54fcbc8f1a854";s:5:"label";s:24:"Caption #1 - second line";s:4:"name";s:23:"homepage-carousel-tag-1";s:4:"type";s:4:"text";s:12:"instructions";s:8:"Optional";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(286, 27, 'theme-header-carousel-image-3', ''),
(287, 27, '_theme-header-carousel-image-3', 'field_54fcbc341a851'),
(288, 27, 'theme-header-carousel-image-4', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(289, 27, '_theme-header-carousel-image-4', 'field_54fcbc5c1a852'),
(290, 27, 'theme-header-carousel-image-5', ''),
(291, 27, '_theme-header-carousel-image-5', 'field_54fcbc6d1a853'),
(292, 27, 'theme-header-carousel-caption-1-line-1', 'A place to work'),
(293, 27, '_theme-header-carousel-caption-1-line-1', 'field_54fca260d31eb'),
(294, 27, 'theme-header-carousel-caption-1-line-2', 'without distraction'),
(295, 27, '_theme-header-carousel-caption-1-line-2', 'field_54fcbc8f1a854'),
(319, 27, 'theme-header-carousel-tag-1', 'without distraction'),
(320, 27, '_theme-header-carousel-tag-1', 'field_54fcbc8f1a854'),
(413, 27, 'theme-header-carousel-caption-2', 'Work/live studio cabins'),
(414, 27, '_theme-header-carousel-caption-2', 'field_54fca2df5a09f'),
(415, 27, 'theme-header-carousel-tag-2', 'designed for specific art-practices'),
(416, 27, '_theme-header-carousel-tag-2', 'field_54fcc2d175bd5'),
(538, 53, 'field_54fcc8526cbdd', 'a:14:{s:3:"key";s:19:"field_54fcc8526cbdd";s:5:"label";s:0:"";s:4:"name";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:16;}'),
(540, 27, 'theme-header-carousel-caption-1-fc', '<span style="color: #000000;">designed for specific art-practices</span>'),
(541, 27, '_theme-header-carousel-caption-1-fc', 'field_54fcc8056cbdc'),
(542, 27, '_', 'field_54fcc8526cbdd'),
(597, 27, 'homepage-carousel-image-1', '44'),
(598, 27, '_homepage-carousel-image-1', 'field_54fca1a0d31ea'),
(599, 27, 'homepage-carousel-caption-1', 'A place to work'),
(600, 27, '_homepage-carousel-caption-1', 'field_54fca260d31eb'),
(601, 27, 'homepage-carousel-tag-1', 'without distraction'),
(602, 27, '_homepage-carousel-tag-1', 'field_54fcbc8f1a854'),
(603, 27, 'homepage-carousel-image-2', '46'),
(604, 27, '_homepage-carousel-image-2', 'field_54fca2b85a09e'),
(605, 27, 'homepage-carousel-image-3', '47'),
(606, 27, '_homepage-carousel-image-3', 'field_54fcbc341a851'),
(607, 27, 'homepage-carousel-image-4', '48'),
(608, 27, '_homepage-carousel-image-4', 'field_54fcbc5c1a852'),
(609, 27, 'homepage-carousel-image-5', '45'),
(610, 27, '_homepage-carousel-image-5', 'field_54fcbc6d1a853'),
(611, 27, 'homepage-carousel-url-1', ''),
(612, 27, '_homepage-carousel-url-1', 'field_54fcafdc06c57'),
(613, 27, 'homepage-carousel-url-2', ''),
(614, 27, '_homepage-carousel-url-2', 'field_54fca2f85a0a0'),
(615, 27, 'homepage-random-carousel-presentation', ''),
(616, 27, '_homepage-random-carousel-presentation', 'field_54fca347d22f1'),
(618, 53, 'field_54fccea0b2e91', 'a:14:{s:3:"key";s:19:"field_54fccea0b2e91";s:5:"label";s:24:"Caption #2 - second line";s:4:"name";s:23:"homepage-carousel-tag-2";s:4:"type";s:4:"text";s:12:"instructions";s:8:"Optional";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:5;}'),
(645, 27, 'homepage-carousel-caption-2', 'Work/live studio cabins'),
(646, 27, '_homepage-carousel-caption-2', 'field_54fca2df5a09f'),
(647, 27, 'homepage-carousel-tag-2', 'designed for specific art-practices'),
(648, 27, '_homepage-carousel-tag-2', 'field_54fccea0b2e91'),
(649, 53, 'field_54fccf3267af6', 'a:14:{s:3:"key";s:19:"field_54fccf3267af6";s:5:"label";s:23:"Caption #3 - first line";s:4:"name";s:27:"homepage-carousel-caption-3";s:4:"type";s:4:"text";s:12:"instructions";s:8:"Optional";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:7;}'),
(650, 53, 'field_54fccf5767af7', 'a:14:{s:3:"key";s:19:"field_54fccf5767af7";s:5:"label";s:24:"Caption #3 - second line";s:4:"name";s:23:"homepage-carousel-tag-3";s:4:"type";s:4:"text";s:12:"instructions";s:8:"Optional";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:8;}'),
(651, 53, 'field_54fccf7b67af8', 'a:14:{s:3:"key";s:19:"field_54fccf7b67af8";s:5:"label";s:23:"Caption #4 - first line";s:4:"name";s:27:"homepage-carousel-caption-4";s:4:"type";s:4:"text";s:12:"instructions";s:8:"Optional";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:10;}'),
(652, 53, 'field_54fccf8e67af9', 'a:14:{s:3:"key";s:19:"field_54fccf8e67af9";s:5:"label";s:24:"Caption #4 - second line";s:4:"name";s:23:"homepage-carousel-tag-4";s:4:"type";s:4:"text";s:12:"instructions";s:8:"Optional";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:11;}'),
(653, 53, 'field_54fccf9e67afa', 'a:14:{s:3:"key";s:19:"field_54fccf9e67afa";s:5:"label";s:23:"Caption #5 - first line";s:4:"name";s:27:"homepage-carousel-caption-5";s:4:"type";s:4:"text";s:12:"instructions";s:8:"Optional";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:13;}'),
(654, 53, 'field_54fccfc167afb', 'a:14:{s:3:"key";s:19:"field_54fccfc167afb";s:5:"label";s:19:"Caption #5 - second";s:4:"name";s:23:"homepage-carousel-tag-5";s:4:"type";s:4:"text";s:12:"instructions";s:8:"Optional";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_54fca347d22f1";s:8:"operator";s:2:"==";s:5:"value";s:3:"yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:14;}'),
(655, 53, 'rule', 'a:5:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"27";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(689, 27, 'homepage-carousel-caption-3', 'Gourmet organic'),
(690, 27, '_homepage-carousel-caption-3', 'field_54fccf3267af6'),
(691, 27, 'homepage-carousel-tag-3', 'meals brought daily to your private studio cabin'),
(692, 27, '_homepage-carousel-tag-3', 'field_54fccf5767af7'),
(693, 27, 'homepage-carousel-caption-4', 'Engaging community'),
(694, 27, '_homepage-carousel-caption-4', 'field_54fccf7b67af8'),
(695, 27, 'homepage-carousel-tag-4', 'live music, lectures, group dinners'),
(696, 27, '_homepage-carousel-tag-4', 'field_54fccf8e67af9'),
(697, 27, 'homepage-carousel-caption-5', 'Monastic environment'),
(698, 27, '_homepage-carousel-caption-5', 'field_54fccf9e67afa'),
(699, 27, 'homepage-carousel-tag-5', 'Wisconsin woodlands, natural waterfalls'),
(700, 27, '_homepage-carousel-tag-5', 'field_54fccfc167afb'),
(701, 72, '_menu_item_type', 'custom'),
(702, 72, '_menu_item_menu_item_parent', '0'),
(703, 72, '_menu_item_object_id', '72'),
(704, 72, '_menu_item_object', 'custom'),
(705, 72, '_menu_item_target', ''),
(706, 72, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(707, 72, '_menu_item_xfn', ''),
(708, 72, '_menu_item_url', 'http://tumblr.com'),
(710, 73, '_menu_item_type', 'custom'),
(711, 73, '_menu_item_menu_item_parent', '0'),
(712, 73, '_menu_item_object_id', '73'),
(713, 73, '_menu_item_object', 'custom'),
(714, 73, '_menu_item_target', ''),
(715, 73, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(716, 73, '_menu_item_xfn', ''),
(717, 73, '_menu_item_url', 'http://twitter.com'),
(719, 74, '_menu_item_type', 'custom'),
(720, 74, '_menu_item_menu_item_parent', '0'),
(721, 74, '_menu_item_object_id', '74'),
(722, 74, '_menu_item_object', 'custom'),
(723, 74, '_menu_item_target', ''),
(724, 74, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(725, 74, '_menu_item_xfn', ''),
(726, 74, '_menu_item_url', 'http://pinterest.com'),
(728, 75, '_menu_item_type', 'custom'),
(729, 75, '_menu_item_menu_item_parent', '0'),
(730, 75, '_menu_item_object_id', '75'),
(731, 75, '_menu_item_object', 'custom'),
(732, 75, '_menu_item_target', ''),
(733, 75, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(734, 75, '_menu_item_xfn', ''),
(735, 75, '_menu_item_url', 'http://facebook.com'),
(737, 76, '_edit_last', '2'),
(738, 76, '_edit_lock', '1426214875:2'),
(739, 78, '_edit_last', '2'),
(740, 78, '_edit_lock', '1426256061:2'),
(741, 80, '_edit_last', '2'),
(742, 80, '_edit_lock', '1426214911:2'),
(743, 82, '_edit_last', '2') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(744, 82, '_edit_lock', '1426214942:2'),
(745, 84, '_edit_last', '2'),
(746, 84, '_edit_lock', '1426215105:2'),
(747, 86, '_edit_last', '2'),
(748, 86, '_edit_lock', '1426214952:2'),
(749, 88, '_edit_last', '2'),
(750, 88, '_edit_lock', '1426214886:2'),
(751, 90, '_edit_last', '2'),
(752, 90, '_edit_lock', '1426214897:2'),
(753, 92, '_edit_last', '2'),
(754, 92, '_edit_lock', '1426214922:2'),
(755, 94, '_menu_item_type', 'post_type'),
(756, 94, '_menu_item_menu_item_parent', '0'),
(757, 94, '_menu_item_object_id', '92'),
(758, 94, '_menu_item_object', 'page'),
(759, 94, '_menu_item_target', ''),
(760, 94, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(761, 94, '_menu_item_xfn', ''),
(762, 94, '_menu_item_url', ''),
(763, 94, '_menu_item_orphaned', '1426182100'),
(764, 95, '_menu_item_type', 'post_type'),
(765, 95, '_menu_item_menu_item_parent', '0'),
(766, 95, '_menu_item_object_id', '90'),
(767, 95, '_menu_item_object', 'page'),
(768, 95, '_menu_item_target', ''),
(769, 95, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(770, 95, '_menu_item_xfn', ''),
(771, 95, '_menu_item_url', ''),
(772, 95, '_menu_item_orphaned', '1426182100'),
(773, 96, '_menu_item_type', 'post_type'),
(774, 96, '_menu_item_menu_item_parent', '0'),
(775, 96, '_menu_item_object_id', '88'),
(776, 96, '_menu_item_object', 'page'),
(777, 96, '_menu_item_target', ''),
(778, 96, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(779, 96, '_menu_item_xfn', ''),
(780, 96, '_menu_item_url', ''),
(781, 96, '_menu_item_orphaned', '1426182100'),
(782, 97, '_menu_item_type', 'post_type'),
(783, 97, '_menu_item_menu_item_parent', '0'),
(784, 97, '_menu_item_object_id', '86'),
(785, 97, '_menu_item_object', 'page'),
(786, 97, '_menu_item_target', ''),
(787, 97, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(788, 97, '_menu_item_xfn', ''),
(789, 97, '_menu_item_url', ''),
(790, 97, '_menu_item_orphaned', '1426182100'),
(791, 98, '_menu_item_type', 'post_type'),
(792, 98, '_menu_item_menu_item_parent', '0'),
(793, 98, '_menu_item_object_id', '84'),
(794, 98, '_menu_item_object', 'page'),
(795, 98, '_menu_item_target', ''),
(796, 98, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(797, 98, '_menu_item_xfn', ''),
(798, 98, '_menu_item_url', ''),
(799, 98, '_menu_item_orphaned', '1426182100'),
(800, 99, '_menu_item_type', 'post_type'),
(801, 99, '_menu_item_menu_item_parent', '0'),
(802, 99, '_menu_item_object_id', '82'),
(803, 99, '_menu_item_object', 'page'),
(804, 99, '_menu_item_target', ''),
(805, 99, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(806, 99, '_menu_item_xfn', ''),
(807, 99, '_menu_item_url', ''),
(808, 99, '_menu_item_orphaned', '1426182100'),
(809, 100, '_menu_item_type', 'post_type'),
(810, 100, '_menu_item_menu_item_parent', '0'),
(811, 100, '_menu_item_object_id', '80'),
(812, 100, '_menu_item_object', 'page'),
(813, 100, '_menu_item_target', ''),
(814, 100, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(815, 100, '_menu_item_xfn', ''),
(816, 100, '_menu_item_url', ''),
(817, 100, '_menu_item_orphaned', '1426182100'),
(818, 101, '_menu_item_type', 'post_type'),
(819, 101, '_menu_item_menu_item_parent', '0'),
(820, 101, '_menu_item_object_id', '78'),
(821, 101, '_menu_item_object', 'page'),
(822, 101, '_menu_item_target', ''),
(823, 101, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(824, 101, '_menu_item_xfn', ''),
(825, 101, '_menu_item_url', ''),
(826, 101, '_menu_item_orphaned', '1426182101'),
(827, 102, '_menu_item_type', 'post_type'),
(828, 102, '_menu_item_menu_item_parent', '0'),
(829, 102, '_menu_item_object_id', '76'),
(830, 102, '_menu_item_object', 'page'),
(831, 102, '_menu_item_target', ''),
(832, 102, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(833, 102, '_menu_item_xfn', ''),
(834, 102, '_menu_item_url', ''),
(835, 102, '_menu_item_orphaned', '1426182101'),
(836, 103, '_menu_item_type', 'post_type'),
(837, 103, '_menu_item_menu_item_parent', '36'),
(838, 103, '_menu_item_object_id', '92'),
(839, 103, '_menu_item_object', 'page'),
(840, 103, '_menu_item_target', ''),
(841, 103, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(842, 103, '_menu_item_xfn', ''),
(843, 103, '_menu_item_url', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(845, 104, '_menu_item_type', 'post_type'),
(846, 104, '_menu_item_menu_item_parent', '36'),
(847, 104, '_menu_item_object_id', '90'),
(848, 104, '_menu_item_object', 'page'),
(849, 104, '_menu_item_target', ''),
(850, 104, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(851, 104, '_menu_item_xfn', ''),
(852, 104, '_menu_item_url', ''),
(854, 105, '_menu_item_type', 'post_type'),
(855, 105, '_menu_item_menu_item_parent', '36'),
(856, 105, '_menu_item_object_id', '88'),
(857, 105, '_menu_item_object', 'page'),
(858, 105, '_menu_item_target', ''),
(859, 105, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(860, 105, '_menu_item_xfn', ''),
(861, 105, '_menu_item_url', ''),
(863, 106, '_menu_item_type', 'post_type'),
(864, 106, '_menu_item_menu_item_parent', '36'),
(865, 106, '_menu_item_object_id', '86'),
(866, 106, '_menu_item_object', 'page'),
(867, 106, '_menu_item_target', ''),
(868, 106, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(869, 106, '_menu_item_xfn', ''),
(870, 106, '_menu_item_url', ''),
(872, 107, '_menu_item_type', 'post_type'),
(873, 107, '_menu_item_menu_item_parent', '36'),
(874, 107, '_menu_item_object_id', '84'),
(875, 107, '_menu_item_object', 'page'),
(876, 107, '_menu_item_target', ''),
(877, 107, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(878, 107, '_menu_item_xfn', ''),
(879, 107, '_menu_item_url', ''),
(881, 108, '_menu_item_type', 'post_type'),
(882, 108, '_menu_item_menu_item_parent', '36'),
(883, 108, '_menu_item_object_id', '82'),
(884, 108, '_menu_item_object', 'page'),
(885, 108, '_menu_item_target', ''),
(886, 108, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(887, 108, '_menu_item_xfn', ''),
(888, 108, '_menu_item_url', ''),
(890, 109, '_menu_item_type', 'post_type'),
(891, 109, '_menu_item_menu_item_parent', '36'),
(892, 109, '_menu_item_object_id', '80'),
(893, 109, '_menu_item_object', 'page'),
(894, 109, '_menu_item_target', ''),
(895, 109, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(896, 109, '_menu_item_xfn', ''),
(897, 109, '_menu_item_url', ''),
(908, 111, '_menu_item_type', 'post_type'),
(909, 111, '_menu_item_menu_item_parent', '36'),
(910, 111, '_menu_item_object_id', '76'),
(911, 111, '_menu_item_object', 'page'),
(912, 111, '_menu_item_target', ''),
(913, 111, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(914, 111, '_menu_item_xfn', ''),
(915, 111, '_menu_item_url', ''),
(917, 112, '_wp_trash_meta_status', 'auto-draft'),
(918, 112, '_wp_trash_meta_time', '1426187858'),
(919, 113, '_edit_last', '2'),
(920, 113, 'field_5501e6757cc82', 'a:12:{s:3:"key";s:19:"field_5501e6757cc82";s:5:"label";s:10:"Cabin Type";s:4:"name";s:10:"cabin_type";s:4:"type";s:6:"select";s:12:"instructions";s:54:"Please choose the type of cabin featured on this page.";s:8:"required";s:1:"1";s:7:"choices";a:6:{s:9:"Painter\'s";s:9:"Painter\'s";s:8:"Ceramics";s:8:"Ceramics";s:12:"Woodworker\'s";s:12:"Woodworker\'s";s:8:"Writer\'s";s:8:"Writer\'s";s:10:"Musician\'s";s:10:"Musician\'s";s:7:"Drawing";s:7:"Drawing";}s:13:"default_value";s:12:"-select one-";s:10:"allow_null";s:1:"0";s:8:"multiple";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(922, 113, 'position', 'side'),
(923, 113, 'layout', 'no_box'),
(924, 113, 'hide_on_screen', ''),
(925, 113, '_edit_lock', '1426190496:2'),
(928, 88, 'cabin_type', 'Writer\'s'),
(929, 88, '_cabin_type', 'field_5501e6757cc82'),
(931, 113, 'rule', 'a:5:{s:5:"param";s:11:"page_parent";s:8:"operator";s:2:"==";s:5:"value";s:1:"2";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(934, 90, 'cabin_type', 'Musician\'s'),
(935, 90, '_cabin_type', 'field_5501e6757cc82'),
(936, 78, 'cabin_type', 'Painter\'s'),
(937, 78, '_cabin_type', 'field_5501e6757cc82'),
(940, 80, 'cabin_type', 'Ceramics'),
(941, 80, '_cabin_type', 'field_5501e6757cc82'),
(944, 92, 'cabin_type', 'Drawing'),
(945, 92, '_cabin_type', 'field_5501e6757cc82'),
(948, 82, 'cabin_type', 'Ceramics'),
(949, 82, '_cabin_type', 'field_5501e6757cc82'),
(952, 86, 'cabin_type', 'Writer\'s'),
(953, 86, '_cabin_type', 'field_5501e6757cc82'),
(956, 84, 'cabin_type', 'Woodworker\'s'),
(957, 84, '_cabin_type', 'field_5501e6757cc82'),
(958, 76, '_wp_page_template', 'page-templates/cabin-page.php'),
(959, 76, 'cabin_type', 'Painter\'s'),
(960, 76, '_cabin_type', 'field_5501e6757cc82'),
(961, 88, '_wp_page_template', 'page-templates/cabin-page.php'),
(962, 90, '_wp_page_template', 'page-templates/cabin-page.php'),
(963, 78, '_wp_page_template', 'page_cabin.php'),
(964, 80, '_wp_page_template', 'page-templates/cabin-page.php'),
(965, 92, '_wp_page_template', 'page-templates/cabin-page.php'),
(966, 82, '_wp_page_template', 'page-templates/cabin-page.php'),
(967, 86, '_wp_page_template', 'page-templates/cabin-page.php'),
(968, 84, '_wp_page_template', 'page-templates/cabin-page.php'),
(969, 121, '_wp_attached_file', '2015/03/background.jpg'),
(970, 121, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:960;s:6:"height";i:864;s:4:"file";s:22:"2015/03/background.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"background-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"background-300x270.jpg";s:5:"width";i:300;s:6:"height";i:270;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(971, 121, '_wp_attachment_image_alt', 'cabin pages background'),
(972, 78, '_thumbnail_id', '121'),
(973, 76, '_wp_trash_meta_status', 'publish'),
(974, 76, '_wp_trash_meta_time', '1426342692'),
(975, 88, '_wp_trash_meta_status', 'publish'),
(976, 88, '_wp_trash_meta_time', '1426342696') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(977, 90, '_wp_trash_meta_status', 'publish'),
(978, 90, '_wp_trash_meta_time', '1426342698'),
(979, 78, '_wp_trash_meta_status', 'publish'),
(980, 78, '_wp_trash_meta_time', '1426342701'),
(981, 80, '_wp_trash_meta_status', 'publish'),
(982, 80, '_wp_trash_meta_time', '1426342703'),
(983, 92, '_wp_trash_meta_status', 'publish'),
(984, 92, '_wp_trash_meta_time', '1426342705'),
(985, 82, '_wp_trash_meta_status', 'publish'),
(986, 82, '_wp_trash_meta_time', '1426342707'),
(987, 86, '_wp_trash_meta_status', 'publish'),
(988, 86, '_wp_trash_meta_time', '1426342709'),
(989, 84, '_wp_trash_meta_status', 'publish'),
(990, 84, '_wp_trash_meta_time', '1426342712'),
(991, 122, '_edit_last', '2'),
(992, 122, '_edit_lock', '1426343456:2'),
(993, 123, '_edit_last', '2'),
(994, 123, '_edit_lock', '1426343535:2'),
(995, 127, '_edit_last', '2'),
(996, 127, '_edit_lock', '1426343629:2'),
(997, 127, '_thumbnail_id', '121'),
(1000, 113, '_wp_trash_meta_status', 'publish'),
(1001, 113, '_wp_trash_meta_time', '1426345653'),
(1002, 129, '_edit_last', '2'),
(1003, 129, 'field_55044ed539ef0', 'a:13:{s:3:"key";s:19:"field_55044ed539ef0";s:5:"label";s:17:"Cabin Description";s:4:"name";s:17:"cabin_description";s:4:"type";s:8:"textarea";s:12:"instructions";s:39:"Please enter a description of the cabin";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:10:"formatting";s:2:"br";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(1004, 129, 'field_55044f1b39ef1', 'a:13:{s:3:"key";s:19:"field_55044f1b39ef1";s:5:"label";s:19:"Art Making Features";s:4:"name";s:19:"art_making_features";s:4:"type";s:8:"textarea";s:12:"instructions";s:51:"Please list the art making features for this cabin.";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:10:"formatting";s:2:"br";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(1005, 129, 'field_55044fc039ef2', 'a:13:{s:3:"key";s:19:"field_55044fc039ef2";s:5:"label";s:23:"Standard Cabin Features";s:4:"name";s:23:"standard_cabin_features";s:4:"type";s:8:"textarea";s:12:"instructions";s:65:"Please enter the standard cabin features included for this cabin.";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:10:"formatting";s:2:"br";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(1008, 129, 'position', 'normal'),
(1009, 129, 'layout', 'no_box'),
(1010, 129, 'hide_on_screen', ''),
(1011, 129, '_edit_lock', '1426366644:2'),
(1025, 130, '_edit_last', '2'),
(1026, 130, '_edit_lock', '1426349077:2'),
(1027, 130, 'cabin_description', 'Filled with natural northern light, the Painter\'s Cabin is perfect for oil, watercolor and acrylic painters.'),
(1028, 130, '_cabin_description', 'field_55044ed539ef0'),
(1029, 130, 'art_making_features', '12\'x16\' plywood painting wall\r\nUtility sink\r\nRolling cart/palette table\r\nFolding easel\r\nAccess to wood shop'),
(1030, 130, '_art_making_features', 'field_55044f1b39ef1'),
(1031, 130, 'standard_cabin_features', '2-top stove\r\nSmall refrigerator\r\nMicrowave\r\nQueen size bed\r\nDresser\r\nDining table/chairs\r\nLounge chair'),
(1032, 130, '_standard_cabin_features', 'field_55044fc039ef2'),
(1033, 130, '_wp_old_slug', 'orchard-painters-cabin-2'),
(1034, 131, '_edit_last', '2'),
(1035, 131, '_edit_lock', '1426367066:2'),
(1037, 131, 'cabin_description', 'Filled with natural northern light, the Painter\'s Cabin is perfect for oil, watercolor and acrylic painters.'),
(1038, 131, '_cabin_description', 'field_55044ed539ef0'),
(1039, 131, 'art_making_features', '12\'x16\' plywood painting wall\r\nUtility sink\r\nRolling cart/palette table\r\nFolding easel\r\nAccess to wood shop'),
(1040, 131, '_art_making_features', 'field_55044f1b39ef1'),
(1041, 131, 'standard_cabin_features', '2-top stove\r\nSmall refrigerator\r\nMicrowave\r\nQueen size bed\r\nDresser\r\nDining table/chairs\r\nLounge chair'),
(1042, 131, '_standard_cabin_features', 'field_55044fc039ef2'),
(1043, 131, '_thumbnail_id', '121'),
(1045, 133, '_wp_trash_meta_status', 'auto-draft'),
(1046, 133, '_wp_trash_meta_time', '1426357783'),
(1047, 134, 'title', 'NextGEN Basic Thumbnails'),
(1048, 134, 'preview_image_relpath', '/nextgen-gallery/products/photocrati_nextgen/modules/nextgen_basic_gallery/static/thumb_preview.jpg'),
(1049, 134, 'default_source', 'galleries'),
(1050, 134, 'view_order', '10000'),
(1051, 134, 'name', 'photocrati-nextgen_basic_thumbnails'),
(1052, 134, 'installed_at_version', '2.0.77.3'),
(1053, 134, 'hidden_from_ui', ''),
(1054, 134, '__defaults_set', '1'),
(1055, 134, 'filter', 'raw'),
(1056, 134, 'entity_types', 'WyJpbWFnZSJd'),
(1057, 134, 'id_field', 'ID'),
(1058, 134, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJpbWFnZXNfcGVyX3BhZ2UiOiIyMCIsIm51bWJlcl9vZl9jb2x1bW5zIjowLCJ0aHVtYm5haWxfd2lkdGgiOjEyMCwidGh1bWJuYWlsX2hlaWdodCI6OTAsInNob3dfYWxsX2luX2xpZ2h0Ym94IjowLCJhamF4X3BhZ2luYXRpb24iOjAsInVzZV9pbWFnZWJyb3dzZXJfZWZmZWN0IjowLCJ0ZW1wbGF0ZSI6IiIsImRpc3BsYXlfbm9faW1hZ2VzX2Vycm9yIjoxLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsInNob3dfc2xpZGVzaG93X2xpbmsiOjEsInNsaWRlc2hvd19saW5rX3RleHQiOiJbU2hvdyBzbGlkZXNob3ddIiwib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjowLCJ0aHVtYm5haWxfcXVhbGl0eSI6IjEwMCIsInRodW1ibmFpbF9jcm9wIjoxLCJ0aHVtYm5haWxfd2F0ZXJtYXJrIjowLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0='),
(1059, 135, 'title', 'NextGEN Basic Slideshow'),
(1060, 135, 'preview_image_relpath', '/nextgen-gallery/products/photocrati_nextgen/modules/nextgen_basic_gallery/static/slideshow_preview.jpg'),
(1061, 135, 'default_source', 'galleries'),
(1062, 135, 'view_order', '10010'),
(1063, 135, 'name', 'photocrati-nextgen_basic_slideshow'),
(1064, 135, 'installed_at_version', '2.0.77.3'),
(1065, 135, 'hidden_from_ui', ''),
(1066, 135, '__defaults_set', '1'),
(1067, 135, 'filter', 'raw'),
(1068, 135, 'entity_types', 'WyJpbWFnZSJd'),
(1069, 135, 'id_field', 'ID'),
(1070, 135, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJnYWxsZXJ5X3dpZHRoIjo2MDAsImdhbGxlcnlfaGVpZ2h0Ijo0MDAsInRodW1ibmFpbF93aWR0aCI6MTIwLCJ0aHVtYm5haWxfaGVpZ2h0Ijo5MCwiY3ljbGVfaW50ZXJ2YWwiOjEwLCJjeWNsZV9lZmZlY3QiOiJmYWRlIiwiZWZmZWN0X2NvZGUiOiJjbGFzcz1cIm5nZy1mYW5jeWJveFwiIHJlbD1cIiVHQUxMRVJZX05BTUUlXCIiLCJzaG93X3RodW1ibmFpbF9saW5rIjoxLCJ0aHVtYm5haWxfbGlua190ZXh0IjoiW1Nob3cgdGh1bWJuYWlsc10iLCJ0ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifQ=='),
(1071, 136, 'title', 'NextGEN Basic ImageBrowser'),
(1072, 136, 'preview_image_relpath', '/nextgen-gallery/products/photocrati_nextgen/modules/nextgen_basic_imagebrowser/static/preview.jpg'),
(1073, 136, 'default_source', 'galleries'),
(1074, 136, 'view_order', '10020'),
(1075, 136, 'name', 'photocrati-nextgen_basic_imagebrowser'),
(1076, 136, 'installed_at_version', '2.0.77.3'),
(1077, 136, 'hidden_from_ui', ''),
(1078, 136, '__defaults_set', '1'),
(1079, 136, 'filter', 'raw'),
(1080, 136, 'entity_types', 'WyJpbWFnZSJd'),
(1081, 136, 'id_field', 'ID'),
(1082, 136, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJ0ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifQ=='),
(1083, 137, 'title', 'NextGEN Basic SinglePic'),
(1084, 137, 'preview_image_relpath', '/nextgen-gallery/products/photocrati_nextgen/modules/nextgen_basic_singlepic/static/preview.gif'),
(1085, 137, 'default_source', 'galleries'),
(1086, 137, 'view_order', '10060'),
(1087, 137, 'hidden_from_ui', '1'),
(1088, 137, 'name', 'photocrati-nextgen_basic_singlepic'),
(1089, 137, 'installed_at_version', '2.0.77.3'),
(1090, 137, '__defaults_set', '1'),
(1091, 137, 'filter', 'raw'),
(1092, 137, 'entity_types', 'WyJpbWFnZSJd'),
(1093, 137, 'id_field', 'ID'),
(1094, 137, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJ3aWR0aCI6IiIsImhlaWdodCI6IiIsIm1vZGUiOiIiLCJkaXNwbGF5X3dhdGVybWFyayI6MCwiZGlzcGxheV9yZWZsZWN0aW9uIjowLCJmbG9hdCI6IiIsImxpbmsiOiIiLCJsaW5rX3RhcmdldCI6Il9ibGFuayIsInF1YWxpdHkiOjEwMCwiY3JvcCI6MCwidGVtcGxhdGUiOiIiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0='),
(1095, 138, 'title', 'NextGEN Basic TagCloud') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1096, 138, 'preview_image_relpath', '/nextgen-gallery/products/photocrati_nextgen/modules/nextgen_basic_tagcloud/static/preview.gif'),
(1097, 138, 'default_source', 'tags'),
(1098, 138, 'view_order', '10100'),
(1099, 138, 'name', 'photocrati-nextgen_basic_tagcloud'),
(1100, 138, 'installed_at_version', '2.0.77.3'),
(1101, 138, 'hidden_from_ui', ''),
(1102, 138, '__defaults_set', '1'),
(1103, 138, 'filter', 'raw'),
(1104, 138, 'entity_types', 'WyJpbWFnZSJd'),
(1105, 138, 'id_field', 'ID'),
(1106, 138, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJkaXNwbGF5X3R5cGUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsIm51bWJlciI6NDUsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifQ=='),
(1107, 139, 'title', 'NextGEN Basic Compact Album'),
(1108, 139, 'preview_image_relpath', '/nextgen-gallery/products/photocrati_nextgen/modules/nextgen_basic_album/static/compact_preview.jpg'),
(1109, 139, 'default_source', 'albums'),
(1110, 139, 'view_order', '10200'),
(1111, 139, 'name', 'photocrati-nextgen_basic_compact_album'),
(1112, 139, 'installed_at_version', '2.0.77.3'),
(1113, 139, 'hidden_from_ui', ''),
(1114, 139, '__defaults_set', '1'),
(1115, 139, 'filter', 'raw'),
(1116, 139, 'entity_types', 'WyJhbGJ1bSIsImdhbGxlcnkiXQ=='),
(1117, 139, 'id_field', 'ID'),
(1118, 139, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJnYWxsZXJpZXNfcGVyX3BhZ2UiOjAsImRpc2FibGVfcGFnaW5hdGlvbiI6MCwidGVtcGxhdGUiOiIiLCJnYWxsZXJ5X2Rpc3BsYXlfdHlwZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwiZ2FsbGVyeV9kaXNwbGF5X3RlbXBsYXRlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciJ9'),
(1119, 140, 'title', 'NextGEN Basic Extended Album'),
(1120, 140, 'preview_image_relpath', '/nextgen-gallery/products/photocrati_nextgen/modules/nextgen_basic_album/static/extended_preview.jpg'),
(1121, 140, 'default_source', 'albums'),
(1122, 140, 'view_order', '10210'),
(1123, 140, 'name', 'photocrati-nextgen_basic_extended_album'),
(1124, 140, 'installed_at_version', '2.0.77.3'),
(1125, 140, 'hidden_from_ui', ''),
(1126, 140, '__defaults_set', '1'),
(1127, 140, 'filter', 'raw'),
(1128, 140, 'entity_types', 'WyJhbGJ1bSIsImdhbGxlcnkiXQ=='),
(1129, 140, 'id_field', 'ID'),
(1130, 140, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJnYWxsZXJpZXNfcGVyX3BhZ2UiOjAsImRpc2FibGVfcGFnaW5hdGlvbiI6MCwidGVtcGxhdGUiOiIiLCJvdmVycmlkZV90aHVtYm5haWxfc2V0dGluZ3MiOjAsInRodW1ibmFpbF93aWR0aCI6MTIwLCJ0aHVtYm5haWxfaGVpZ2h0Ijo5MCwidGh1bWJuYWlsX3F1YWxpdHkiOjEwMCwidGh1bWJuYWlsX2Nyb3AiOnRydWUsInRodW1ibmFpbF93YXRlcm1hcmsiOjAsImdhbGxlcnlfZGlzcGxheV90eXBlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiLCJnYWxsZXJ5X2Rpc3BsYXlfdGVtcGxhdGUiOiIiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0='),
(1133, 141, '__defaults_set', '1'),
(1134, 141, 'filter', 'raw'),
(1135, 141, 'id_field', 'ID'),
(1136, 142, '__defaults_set', '1'),
(1137, 142, 'filter', 'raw'),
(1138, 142, 'id_field', 'ID'),
(1148, 145, '__defaults_set', '1'),
(1149, 145, 'filter', 'raw'),
(1150, 145, 'id_field', 'ID'),
(1157, 147, '__defaults_set', '1'),
(1158, 147, 'filter', 'raw'),
(1159, 147, 'id_field', 'ID'),
(1169, 144, '__defaults_set', '1'),
(1170, 144, 'filter', 'raw'),
(1171, 144, 'id_field', 'ID'),
(1172, 143, '__defaults_set', '1'),
(1173, 143, 'filter', 'raw'),
(1174, 143, 'id_field', 'ID'),
(1175, 146, '__defaults_set', '1'),
(1176, 146, 'filter', 'raw'),
(1177, 146, 'id_field', 'ID'),
(1178, 148, '__defaults_set', '1'),
(1179, 148, 'filter', 'raw'),
(1180, 148, 'id_field', 'ID'),
(1181, 149, '__defaults_set', '1'),
(1182, 149, 'filter', 'raw'),
(1183, 149, 'id_field', 'ID'),
(1184, 131, 'cabin_images', 'a:1:{i:0;s:1:"2";}'),
(1185, 131, '_cabin_images', 'field_550480860ed0c'),
(1186, 150, '_wp_attached_file', '2015/03/cabin1.jpg'),
(1187, 150, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:510;s:6:"height";i:400;s:4:"file";s:18:"2015/03/cabin1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"cabin1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"cabin1-300x235.jpg";s:5:"width";i:300;s:6:"height";i:235;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1188, 151, '_wp_attached_file', '2015/03/cabin2.jpg'),
(1189, 151, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:310;s:6:"height";i:400;s:4:"file";s:18:"2015/03/cabin2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"cabin2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"cabin2-233x300.jpg";s:5:"width";i:233;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1190, 152, '_wp_attached_file', '2015/03/cabin3.jpg'),
(1191, 152, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:310;s:6:"height";i:400;s:4:"file";s:18:"2015/03/cabin3.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"cabin3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"cabin3-233x300.jpg";s:5:"width";i:233;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1193, 129, 'field_55049ff471517', 'a:13:{s:3:"key";s:19:"field_55049ff471517";s:5:"label";s:17:"Cabin Rental Cost";s:4:"name";s:17:"cabin_rental_cost";s:4:"type";s:8:"textarea";s:12:"instructions";s:49:"Please enter each cost associated with the cabin.";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:10:"formatting";s:2:"br";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}'),
(1195, 131, 'cabin_rental_cost', '$50 per night without a meal plan\r\n$75 per night with meal plan'),
(1196, 131, '_cabin_rental_cost', 'field_55049ff471517'),
(1197, 129, 'field_5504a12bff436', 'a:8:{s:3:"key";s:19:"field_5504a12bff436";s:5:"label";s:18:"Check Availability";s:4:"name";s:18:"check_availability";s:4:"type";s:6:"button";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}'),
(1198, 129, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"cabin";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(1199, 131, 'check_availability', 'a:4:{s:4:"text";s:18:"check availability";s:4:"link";s:0:"";s:7:"page_id";s:2:"16";s:12:"use_internal";s:0:"";}'),
(1200, 131, '_check_availability', 'field_5504a12bff436'),
(1201, 153, '_menu_item_type', 'post_type'),
(1202, 153, '_menu_item_menu_item_parent', '0'),
(1203, 153, '_menu_item_object_id', '131'),
(1204, 153, '_menu_item_object', 'cabin'),
(1205, 153, '_menu_item_target', ''),
(1206, 153, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1207, 153, '_menu_item_xfn', ''),
(1208, 153, '_menu_item_url', ''),
(1209, 153, '_menu_item_orphaned', '1426367246'),
(1210, 154, '_menu_item_type', 'post_type'),
(1211, 154, '_menu_item_menu_item_parent', '36'),
(1212, 154, '_menu_item_object_id', '131'),
(1213, 154, '_menu_item_object', 'cabin'),
(1214, 154, '_menu_item_target', ''),
(1215, 154, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1216, 154, '_menu_item_xfn', ''),
(1217, 154, '_menu_item_url', '') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 2, '2015-02-16 19:52:16', '2015-02-16 19:52:16', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world', '', '', '2015-03-08 16:37:23', '2015-03-08 16:37:23', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=1', 0, 'post', '', 0),
(2, 2, '2015-02-16 19:52:16', '2015-02-16 19:52:16', '<div id="lipsum">\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sed sem sodales, scelerisque nunc at, maximus lorem. Quisque auctor felis quis libero consequat vestibulum. Vestibulum lacinia eu metus non dictum. Aenean vitae dolor odio. Aenean at aliquam nisl. Etiam rutrum accumsan facilisis. Praesent id tortor eget nunc aliquet elementum. Praesent volutpat augue sit amet libero tincidunt, non malesuada ante elementum. Suspendisse potenti.\r\n\r\nQuisque at elementum lectus. Nam sollicitudin nibh quis tortor egestas porta. Nullam ac porttitor magna. Mauris eget finibus neque. Integer a eros at ex scelerisque faucibus. Integer nec nibh diam. Donec fringilla nibh vitae mauris tincidunt, quis vulputate diam tempor.\r\n\r\n</div>', 'Studio Cabins', '', 'publish', 'open', 'open', '', 'studio-cabins', '', '', '2015-03-08 16:34:06', '2015-03-08 16:34:06', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?page_id=2', 0, 'page', '', 0),
(4, 2, '2015-03-04 18:48:33', '2015-03-04 18:48:33', 'Does this even work?', 'test post', '', 'trash', 'open', 'open', '', 'test-post', '', '', '2015-03-04 19:45:40', '2015-03-04 19:45:40', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=4', 0, 'post', '', 0),
(10, 2, '2015-03-07 16:36:06', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'open', 'open', '', '', '', '', '2015-03-07 16:36:06', '0000-00-00 00:00:00', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=10', 1, 'nav_menu_item', '', 0),
(11, 2, '2015-03-07 16:36:06', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2015-03-07 16:36:06', '0000-00-00 00:00:00', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=11', 1, 'nav_menu_item', '', 0),
(12, 2, '2015-03-07 16:37:03', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'open', 'open', '', '', '', '', '2015-03-07 16:37:03', '0000-00-00 00:00:00', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=12', 1, 'nav_menu_item', '', 0),
(13, 2, '2015-03-07 16:37:03', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2015-03-07 16:37:03', '0000-00-00 00:00:00', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=13', 1, 'nav_menu_item', '', 0),
(16, 2, '2015-03-07 16:39:39', '2015-03-07 16:39:39', '<div id="lipsum">\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sed sem sodales, scelerisque nunc at, maximus lorem. Quisque auctor felis quis libero consequat vestibulum. Vestibulum lacinia eu metus non dictum. Aenean vitae dolor odio. Aenean at aliquam nisl. Etiam rutrum accumsan facilisis. Praesent id tortor eget nunc aliquet elementum. Praesent volutpat augue sit amet libero tincidunt, non malesuada ante elementum. Suspendisse potenti.\r\n\r\nQuisque at elementum lectus. Nam sollicitudin nibh quis tortor egestas porta. Nullam ac porttitor magna. Mauris eget finibus neque. Integer a eros at ex scelerisque faucibus. Integer nec nibh diam. Donec fringilla nibh vitae mauris tincidunt, quis vulputate diam tempor.\r\n\r\n</div>', 'Apply', '', 'publish', 'open', 'open', '', 'apply', '', '', '2015-03-07 16:39:39', '2015-03-07 16:39:39', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?page_id=16', 0, 'page', '', 0),
(18, 2, '2015-03-07 16:39:53', '2015-03-07 16:39:53', '<div id="lipsum">\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sed sem sodales, scelerisque nunc at, maximus lorem. Quisque auctor felis quis libero consequat vestibulum. Vestibulum lacinia eu metus non dictum. Aenean vitae dolor odio. Aenean at aliquam nisl. Etiam rutrum accumsan facilisis. Praesent id tortor eget nunc aliquet elementum. Praesent volutpat augue sit amet libero tincidunt, non malesuada ante elementum. Suspendisse potenti.\r\n\r\nQuisque at elementum lectus. Nam sollicitudin nibh quis tortor egestas porta. Nullam ac porttitor magna. Mauris eget finibus neque. Integer a eros at ex scelerisque faucibus. Integer nec nibh diam. Donec fringilla nibh vitae mauris tincidunt, quis vulputate diam tempor.\r\n\r\n</div>', 'Meals', '', 'publish', 'open', 'open', '', 'meals', '', '', '2015-03-07 16:39:53', '2015-03-07 16:39:53', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?page_id=18', 0, 'page', '', 0),
(20, 2, '2015-03-07 16:40:05', '2015-03-07 16:40:05', '<div id="lipsum">\r\n\r\n&nbsp;\r\n\r\n</div>', 'Events', '', 'publish', 'open', 'open', '', 'events', '', '', '2015-03-08 14:38:57', '2015-03-08 14:38:57', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?page_id=20', 0, 'page', '', 0),
(22, 2, '2015-03-07 16:40:15', '2015-03-07 16:40:15', '<div id="lipsum">\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sed sem sodales, scelerisque nunc at, maximus lorem. Quisque auctor felis quis libero consequat vestibulum. Vestibulum lacinia eu metus non dictum. Aenean vitae dolor odio. Aenean at aliquam nisl. Etiam rutrum accumsan facilisis. Praesent id tortor eget nunc aliquet elementum. Praesent volutpat augue sit amet libero tincidunt, non malesuada ante elementum. Suspendisse potenti.\r\n\r\nQuisque at elementum lectus. Nam sollicitudin nibh quis tortor egestas porta. Nullam ac porttitor magna. Mauris eget finibus neque. Integer a eros at ex scelerisque faucibus. Integer nec nibh diam. Donec fringilla nibh vitae mauris tincidunt, quis vulputate diam tempor.\r\n\r\n</div>', 'Location', '', 'publish', 'open', 'open', '', 'location', '', '', '2015-03-07 16:40:15', '2015-03-07 16:40:15', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?page_id=22', 0, 'page', '', 0),
(24, 2, '2015-03-07 16:40:23', '2015-03-07 16:40:23', '<div id="lipsum">\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sed sem sodales, scelerisque nunc at, maximus lorem. Quisque auctor felis quis libero consequat vestibulum. Vestibulum lacinia eu metus non dictum. Aenean vitae dolor odio. Aenean at aliquam nisl. Etiam rutrum accumsan facilisis. Praesent id tortor eget nunc aliquet elementum. Praesent volutpat augue sit amet libero tincidunt, non malesuada ante elementum. Suspendisse potenti.\r\n\r\nQuisque at elementum lectus. Nam sollicitudin nibh quis tortor egestas porta. Nullam ac porttitor magna. Mauris eget finibus neque. Integer a eros at ex scelerisque faucibus. Integer nec nibh diam. Donec fringilla nibh vitae mauris tincidunt, quis vulputate diam tempor.\r\n\r\n</div>', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2015-03-07 16:40:31', '2015-03-07 16:40:31', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?page_id=24', 0, 'page', '', 0),
(27, 2, '2015-03-07 16:41:21', '2015-03-07 16:41:21', '', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2015-03-08 22:42:13', '2015-03-08 22:42:13', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?page_id=27', 0, 'page', '', 0),
(29, 2, '2015-03-07 16:42:00', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'open', 'open', '', '', '', '', '2015-03-07 16:42:00', '0000-00-00 00:00:00', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=29', 1, 'nav_menu_item', '', 0),
(30, 2, '2015-03-07 16:43:09', '2015-03-07 16:43:09', ' ', '', '', 'publish', 'open', 'closed', '', '30', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=30', 15, 'nav_menu_item', '', 0),
(31, 2, '2015-03-07 16:43:09', '2015-03-07 16:43:09', ' ', '', '', 'publish', 'open', 'closed', '', '31', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=31', 11, 'nav_menu_item', '', 0),
(32, 2, '2015-03-07 16:43:09', '2015-03-07 16:43:09', ' ', '', '', 'publish', 'open', 'closed', '', '32', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=32', 13, 'nav_menu_item', '', 0),
(33, 2, '2015-03-07 16:42:00', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2015-03-07 16:42:00', '0000-00-00 00:00:00', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=33', 1, 'nav_menu_item', '', 0),
(34, 2, '2015-03-07 16:43:09', '2015-03-07 16:43:09', ' ', '', '', 'publish', 'open', 'closed', '', '34', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=34', 14, 'nav_menu_item', '', 0),
(35, 2, '2015-03-07 16:43:09', '2015-03-07 16:43:09', ' ', '', '', 'publish', 'open', 'closed', '', '35', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=35', 12, 'nav_menu_item', '', 0),
(36, 2, '2015-03-07 16:43:09', '2015-03-07 16:43:09', ' ', '', '', 'publish', 'open', 'closed', '', '36', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=36', 1, 'nav_menu_item', '', 0),
(43, 2, '2015-03-08 16:50:43', '2015-03-08 16:50:43', '', 'Homepage', '', 'publish', 'closed', 'closed', '', 'new-slider', '', '', '2015-03-08 18:12:14', '2015-03-08 18:12:14', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=ml-slider&#038;p=43', 0, 'ml-slider', '', 0),
(44, 2, '2015-03-08 16:51:48', '2015-03-08 16:51:48', 'without distraction', 'homepage1', 'A place to work\nwithout distraction', 'inherit', 'closed', 'closed', '', 'homepage1-2', '', '', '2015-03-08 19:03:59', '2015-03-08 19:03:59', '', 0, 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/homepage1.jpg', 0, 'attachment', 'image/jpeg', 0),
(45, 2, '2015-03-08 16:51:49', '2015-03-08 16:51:49', '', 'homepage5', 'MONASTIC ENVIRONMENT\nWisconsin woodlands, natural waterfalls', 'inherit', 'closed', 'closed', '', 'homepage2', '', '', '2015-03-08 21:40:32', '2015-03-08 21:40:32', '', 0, 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/homepage2.jpg', 4, 'attachment', 'image/jpeg', 0),
(46, 2, '2015-03-08 16:51:50', '2015-03-08 16:51:50', '', 'homepage2', 'WORK/LIVE STUDIO CABINS\ndesigned for specific art-practices', 'inherit', 'closed', 'closed', '', 'homepage3', '', '', '2015-03-08 19:34:00', '2015-03-08 19:34:00', '', 0, 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/homepage3.jpg', 1, 'attachment', 'image/jpeg', 0),
(47, 2, '2015-03-08 16:51:50', '2015-03-08 16:51:50', '', 'homepage3', 'GOURMET ORGANIC\nmeals brought daily to your private studio cabin', 'inherit', 'closed', 'closed', '', 'homepage4', '', '', '2015-03-08 21:40:19', '2015-03-08 21:40:19', '', 0, 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/homepage4.jpg', 2, 'attachment', 'image/jpeg', 0),
(48, 2, '2015-03-08 16:51:51', '2015-03-08 16:51:51', '', 'homepage4', 'ENGAGING COMMUNITY\nlive music, lectures, group dinners', 'inherit', 'closed', 'closed', '', 'homepage5', '', '', '2015-03-08 21:40:27', '2015-03-08 21:40:27', '', 0, 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/homepage5.jpg', 3, 'attachment', 'image/jpeg', 0),
(53, 2, '2015-03-08 19:22:50', '2015-03-08 19:22:50', '', 'Homepage Carousel', '', 'publish', 'closed', 'closed', '', 'acf_homepage-carousel', '', '', '2015-03-08 22:40:59', '2015-03-08 22:40:59', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=acf&#038;p=53', 0, 'acf', '', 0),
(71, 2, '2015-03-09 17:59:26', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-03-09 17:59:26', '0000-00-00 00:00:00', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=71', 0, 'post', '', 0),
(72, 2, '2015-03-11 18:05:25', '2015-03-11 18:05:25', '', 'Tumblr', '', 'publish', 'closed', 'closed', '', 'tumblr', '', '', '2015-03-11 20:32:31', '2015-03-11 20:32:31', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=72', 1, 'nav_menu_item', '', 0),
(73, 2, '2015-03-11 18:05:25', '2015-03-11 18:05:25', '', 'Twitter', '', 'publish', 'closed', 'closed', '', 'twitter', '', '', '2015-03-11 20:32:31', '2015-03-11 20:32:31', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=73', 2, 'nav_menu_item', '', 0),
(74, 2, '2015-03-11 18:05:25', '2015-03-11 18:05:25', '', 'Pinterest', '', 'publish', 'closed', 'closed', '', 'pinterest', '', '', '2015-03-11 20:32:31', '2015-03-11 20:32:31', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=74', 3, 'nav_menu_item', '', 0),
(75, 2, '2015-03-11 18:05:25', '2015-03-11 18:05:25', '', 'Facebook', '', 'publish', 'closed', 'closed', '', 'facebook', '', '', '2015-03-11 20:32:31', '2015-03-11 20:32:31', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=75', 4, 'nav_menu_item', '', 0),
(76, 2, '2015-03-12 17:36:50', '2015-03-12 17:36:50', '', 'Hillside Painter\'s Cabin', '', 'trash', 'closed', 'closed', '', 'hillside-painters-cabin', '', '', '2015-03-14 14:18:12', '2015-03-14 14:18:12', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?page_id=76', 0, 'page', '', 0),
(78, 2, '2015-03-12 17:37:58', '2015-03-12 17:37:58', '', 'Orchard Painter\'s Cabin', '', 'trash', 'closed', 'closed', '', 'orchard-painters-cabin', '', '', '2015-03-14 14:18:21', '2015-03-14 14:18:21', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?page_id=78', 0, 'page', '', 0),
(80, 2, '2015-03-12 17:38:39', '2015-03-12 17:38:39', '', 'Prairie Ceramics Cabin', '', 'trash', 'closed', 'closed', '', 'prairie-ceramics-cabin', '', '', '2015-03-14 14:18:23', '2015-03-14 14:18:23', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?page_id=80', 0, 'page', '', 0),
(82, 2, '2015-03-12 17:39:02', '2015-03-12 17:39:02', '', 'Woodland Ceramics Cabin', '', 'trash', 'closed', 'closed', '', 'woodland-ceramics-cabin', '', '', '2015-03-14 14:18:27', '2015-03-14 14:18:27', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?page_id=82', 0, 'page', '', 0),
(84, 2, '2015-03-12 17:39:31', '2015-03-12 17:39:31', '', 'Woodworker\'s Cabin', '', 'trash', 'closed', 'closed', '', 'woodworkers-cabin', '', '', '2015-03-14 14:18:32', '2015-03-14 14:18:32', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?page_id=84', 0, 'page', '', 0),
(86, 2, '2015-03-12 17:39:51', '2015-03-12 17:39:51', '', 'Woodland Writer\'s Cabin', '', 'trash', 'closed', 'closed', '', 'woodland-writers-cabin', '', '', '2015-03-14 14:18:29', '2015-03-14 14:18:29', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?page_id=86', 0, 'page', '', 0),
(88, 2, '2015-03-12 17:40:08', '2015-03-12 17:40:08', '', 'Hillside Writer\'s Cabin', '', 'trash', 'closed', 'closed', '', 'hillside-writers-cabin', '', '', '2015-03-14 14:18:16', '2015-03-14 14:18:16', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?page_id=88', 0, 'page', '', 0),
(90, 2, '2015-03-12 17:40:30', '2015-03-12 17:40:30', '', 'Musician\'s Cabin', '', 'trash', 'closed', 'closed', '', 'musicians-cabin', '', '', '2015-03-14 14:18:18', '2015-03-14 14:18:18', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?page_id=90', 0, 'page', '', 0),
(92, 2, '2015-03-12 17:41:10', '2015-03-12 17:41:10', '', 'Valley Drawing Cabin', '', 'trash', 'closed', 'closed', '', 'valley-drawing-cabin', '', '', '2015-03-14 14:18:25', '2015-03-14 14:18:25', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?page_id=92', 0, 'page', '', 0),
(94, 2, '2015-03-12 17:41:40', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-12 17:41:40', '0000-00-00 00:00:00', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=94', 1, 'nav_menu_item', '', 0),
(95, 2, '2015-03-12 17:41:40', '0000-00-00 00:00:00', '', 'Musician\'s Cabin', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-12 17:41:40', '0000-00-00 00:00:00', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=95', 1, 'nav_menu_item', '', 0),
(96, 2, '2015-03-12 17:41:40', '0000-00-00 00:00:00', '', 'Hillside Writer\'s Cabin', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-12 17:41:40', '0000-00-00 00:00:00', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=96', 1, 'nav_menu_item', '', 0),
(97, 2, '2015-03-12 17:41:40', '0000-00-00 00:00:00', '', 'Woodland Writer\'s Cabin', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-12 17:41:40', '0000-00-00 00:00:00', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=97', 1, 'nav_menu_item', '', 0),
(98, 2, '2015-03-12 17:41:40', '0000-00-00 00:00:00', '', 'Woodworker\'s Cabin', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-12 17:41:40', '0000-00-00 00:00:00', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=98', 1, 'nav_menu_item', '', 0),
(99, 2, '2015-03-12 17:41:40', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-12 17:41:40', '0000-00-00 00:00:00', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=99', 1, 'nav_menu_item', '', 0),
(100, 2, '2015-03-12 17:41:40', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-12 17:41:40', '0000-00-00 00:00:00', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=100', 1, 'nav_menu_item', '', 0),
(101, 2, '2015-03-12 17:41:40', '0000-00-00 00:00:00', '', 'Orchard Painter\'s Cabin', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-12 17:41:40', '0000-00-00 00:00:00', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=101', 1, 'nav_menu_item', '', 0),
(102, 2, '2015-03-12 17:41:41', '0000-00-00 00:00:00', '', 'Hillside Painter\'s Cabin', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-12 17:41:41', '0000-00-00 00:00:00', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=102', 1, 'nav_menu_item', '', 0),
(103, 2, '2015-03-12 17:43:20', '2015-03-12 17:43:20', ' ', '', '', 'publish', 'closed', 'closed', '', '103', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=103', 10, 'nav_menu_item', '', 0),
(104, 2, '2015-03-12 17:43:20', '2015-03-12 17:43:20', '', 'Musician\'s Cabin', '', 'publish', 'closed', 'closed', '', 'musicians-cabin', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=104', 9, 'nav_menu_item', '', 0),
(105, 2, '2015-03-12 17:43:20', '2015-03-12 17:43:20', '', 'Hillside Writer\'s Cabin', '', 'publish', 'closed', 'closed', '', 'hillside-writers-cabin', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=105', 8, 'nav_menu_item', '', 0),
(106, 2, '2015-03-12 17:43:20', '2015-03-12 17:43:20', '', 'Woodland Writer\'s Cabin', '', 'publish', 'closed', 'closed', '', 'woodland-writers-cabin', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=106', 7, 'nav_menu_item', '', 0),
(107, 2, '2015-03-12 17:43:20', '2015-03-12 17:43:20', '', 'Woodworker\'s Cabin', '', 'publish', 'closed', 'closed', '', 'woodworkers-cabin', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=107', 6, 'nav_menu_item', '', 0),
(108, 2, '2015-03-12 17:43:20', '2015-03-12 17:43:20', ' ', '', '', 'publish', 'closed', 'closed', '', '108', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=108', 5, 'nav_menu_item', '', 0),
(109, 2, '2015-03-12 17:43:20', '2015-03-12 17:43:20', ' ', '', '', 'publish', 'closed', 'closed', '', '109', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=109', 4, 'nav_menu_item', '', 0),
(111, 2, '2015-03-12 17:43:20', '2015-03-12 17:43:20', '', 'Hillside Painter\'s Cabin', '', 'publish', 'closed', 'closed', '', 'hillside-painters-cabin', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 2, 'http://sanctuary.lisawolfsonmyers.com/?p=111', 2, 'nav_menu_item', '', 0),
(112, 2, '2015-03-12 19:17:25', '2015-03-12 19:17:25', '', 'Auto Draft', '', 'trash', 'closed', 'closed', '', 'auto-draft', '', '', '2015-03-12 19:17:38', '2015-03-12 19:17:38', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=acf&#038;p=112', 0, 'acf', '', 0),
(113, 2, '2015-03-12 19:20:42', '2015-03-12 19:20:42', '', 'Cabin Categories', '', 'trash', 'closed', 'closed', '', 'acf_cabin-categories', '', '', '2015-03-14 15:07:33', '2015-03-14 15:07:33', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=acf&#038;p=113', 0, 'acf', '', 0),
(121, 2, '2015-03-12 20:56:07', '2015-03-12 20:56:07', '', 'Cabin pages background', '', 'inherit', 'closed', 'closed', '', 'background', '', '', '2015-03-12 20:56:42', '2015-03-12 20:56:42', '', 78, 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/background.jpg', 0, 'attachment', 'image/jpeg', 0),
(122, 2, '2015-03-14 14:30:56', '0000-00-00 00:00:00', '', 'Orchard Painter\'s Cabin', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-14 14:30:56', '2015-03-14 14:30:56', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=cabin_posts&#038;p=122', 0, 'cabin_posts', '', 0),
(123, 2, '2015-03-14 14:32:15', '0000-00-00 00:00:00', '', 'Orchard Painter\'s Cabin', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-14 14:32:15', '2015-03-14 14:32:15', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=cabin_posts&#038;p=123', 0, 'cabin_posts', '', 0),
(124, 2, '2015-03-14 14:34:16', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-03-14 14:34:16', '0000-00-00 00:00:00', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=cabin_posts&p=124', 0, 'cabin_posts', '', 0),
(125, 2, '2015-03-14 14:35:15', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-03-14 14:35:15', '0000-00-00 00:00:00', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=cabin_posts&p=125', 0, 'cabin_posts', '', 0),
(126, 2, '2015-03-14 14:35:28', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-03-14 14:35:28', '0000-00-00 00:00:00', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=cabin_posts&p=126', 0, 'cabin_posts', '', 0),
(127, 2, '2015-03-14 14:36:07', '2015-03-14 14:36:07', '', 'Orchard Painter\'s Cabin', '', 'publish', 'closed', 'closed', '', 'orchard-painters-cabin', '', '', '2015-03-14 14:36:10', '2015-03-14 14:36:10', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=cabin_posts&#038;p=127', 0, 'cabin_posts', '', 0),
(129, 2, '2015-03-14 15:14:59', '2015-03-14 15:14:59', '', 'Studio Cabins', '', 'publish', 'closed', 'closed', '', 'acf_studio-cabins', '', '', '2015-03-14 20:59:46', '2015-03-14 20:59:46', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=acf&#038;p=129', 0, 'acf', '', 0),
(130, 2, '2015-03-14 16:03:44', '2015-03-14 16:03:44', '', 'Orchard Painter\'s Cabin', '', 'publish', 'closed', 'closed', '', 'orchard-painters-cabin', '', '', '2015-03-14 16:04:36', '2015-03-14 16:04:36', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=cabin_post&#038;p=130', 0, 'cabin_post', '', 0),
(131, 2, '2015-03-14 16:10:33', '2015-03-14 16:10:33', '', 'Orchard Painter\'s Cabin', '', 'publish', 'closed', 'closed', '', 'orchard-painters-cabin', '', '', '2015-03-14 21:00:22', '2015-03-14 21:00:22', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=cabin&#038;p=131', 0, 'cabin', '', 0),
(133, 2, '2015-03-14 18:29:20', '2015-03-14 18:29:20', '', 'Auto Draft', '', 'trash', 'closed', 'closed', '', 'auto-draft-2', '', '', '2015-03-14 18:29:43', '2015-03-14 18:29:43', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=acf&#038;p=133', 0, 'acf', '', 0),
(134, 2, '2015-03-14 18:38:22', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgVGh1bWJuYWlscyIsImVudGl0eV90eXBlcyI6WyJpbWFnZSJdLCJwcmV2aWV3X2ltYWdlX3JlbHBhdGgiOiJcL25leHRnZW4tZ2FsbGVyeVwvcHJvZHVjdHNcL3Bob3RvY3JhdGlfbmV4dGdlblwvbW9kdWxlc1wvbmV4dGdlbl9iYXNpY19nYWxsZXJ5XC9zdGF0aWNcL3RodW1iX3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDAwMCwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIyLjAuNzcuMyIsImlkX2ZpZWxkIjoiSUQiLCJzZXR0aW5ncyI6eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJpbWFnZXNfcGVyX3BhZ2UiOiIyMCIsIm51bWJlcl9vZl9jb2x1bW5zIjowLCJ0aHVtYm5haWxfd2lkdGgiOjEyMCwidGh1bWJuYWlsX2hlaWdodCI6OTAsInNob3dfYWxsX2luX2xpZ2h0Ym94IjowLCJhamF4X3BhZ2luYXRpb24iOjAsInVzZV9pbWFnZWJyb3dzZXJfZWZmZWN0IjowLCJ0ZW1wbGF0ZSI6IiIsImRpc3BsYXlfbm9faW1hZ2VzX2Vycm9yIjoxLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsInNob3dfc2xpZGVzaG93X2xpbmsiOjEsInNsaWRlc2hvd19saW5rX3RleHQiOiJbU2hvdyBzbGlkZXNob3ddIiwib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjowLCJ0aHVtYm5haWxfcXVhbGl0eSI6IjEwMCIsInRodW1ibmFpbF9jcm9wIjoxLCJ0aHVtYm5haWxfd2F0ZXJtYXJrIjowLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'NextGEN Basic Thumbnails', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-14 18:38:22', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgVGh1bWJuYWlscyIsImVudGl0eV90eXBlcyI6WyJpbWFnZSJdLCJwcmV2aWV3X2ltYWdlX3JlbHBhdGgiOiJcL25leHRnZW4tZ2FsbGVyeVwvcHJvZHVjdHNcL3Bob3RvY3JhdGlfbmV4dGdlblwvbW9kdWxlc1wvbmV4dGdlbl9iYXNpY19nYWxsZXJ5XC9zdGF0aWNcL3RodW1iX3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDAwMCwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIyLjAuNzcuMyIsImlkX2ZpZWxkIjoiSUQiLCJzZXR0aW5ncyI6eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJpbWFnZXNfcGVyX3BhZ2UiOiIyMCIsIm51bWJlcl9vZl9jb2x1bW5zIjowLCJ0aHVtYm5haWxfd2lkdGgiOjEyMCwidGh1bWJuYWlsX2hlaWdodCI6OTAsInNob3dfYWxsX2luX2xpZ2h0Ym94IjowLCJhamF4X3BhZ2luYXRpb24iOjAsInVzZV9pbWFnZWJyb3dzZXJfZWZmZWN0IjowLCJ0ZW1wbGF0ZSI6IiIsImRpc3BsYXlfbm9faW1hZ2VzX2Vycm9yIjoxLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsInNob3dfc2xpZGVzaG93X2xpbmsiOjEsInNsaWRlc2hvd19saW5rX3RleHQiOiJbU2hvdyBzbGlkZXNob3ddIiwib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjowLCJ0aHVtYm5haWxfcXVhbGl0eSI6IjEwMCIsInRodW1ibmFpbF9jcm9wIjoxLCJ0aHVtYm5haWxfd2F0ZXJtYXJrIjowLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=display_type&p=134', 0, 'display_type', '', 0),
(135, 2, '2015-03-14 18:38:22', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgU2xpZGVzaG93IiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlwvbmV4dGdlbi1nYWxsZXJ5XC9wcm9kdWN0c1wvcGhvdG9jcmF0aV9uZXh0Z2VuXC9tb2R1bGVzXC9uZXh0Z2VuX2Jhc2ljX2dhbGxlcnlcL3N0YXRpY1wvc2xpZGVzaG93X3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDAxMCwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19zbGlkZXNob3ciLCJpbnN0YWxsZWRfYXRfdmVyc2lvbiI6IjIuMC43Ny4zIiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7InVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImdhbGxlcnlfd2lkdGgiOjYwMCwiZ2FsbGVyeV9oZWlnaHQiOjQwMCwidGh1bWJuYWlsX3dpZHRoIjoxMjAsInRodW1ibmFpbF9oZWlnaHQiOjkwLCJjeWNsZV9pbnRlcnZhbCI6MTAsImN5Y2xlX2VmZmVjdCI6ImZhZGUiLCJlZmZlY3RfY29kZSI6ImNsYXNzPVwibmdnLWZhbmN5Ym94XCIgcmVsPVwiJUdBTExFUllfTkFNRSVcIiIsInNob3dfdGh1bWJuYWlsX2xpbmsiOjEsInRodW1ibmFpbF9saW5rX3RleHQiOiJbU2hvdyB0aHVtYm5haWxzXSIsInRlbXBsYXRlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciJ9LCJoaWRkZW5fZnJvbV91aSI6ZmFsc2UsIl9fZGVmYXVsdHNfc2V0Ijp0cnVlfQ==', 'NextGEN Basic Slideshow', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-14 18:38:22', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgU2xpZGVzaG93IiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlwvbmV4dGdlbi1nYWxsZXJ5XC9wcm9kdWN0c1wvcGhvdG9jcmF0aV9uZXh0Z2VuXC9tb2R1bGVzXC9uZXh0Z2VuX2Jhc2ljX2dhbGxlcnlcL3N0YXRpY1wvc2xpZGVzaG93X3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDAxMCwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19zbGlkZXNob3ciLCJpbnN0YWxsZWRfYXRfdmVyc2lvbiI6IjIuMC43Ny4zIiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7InVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImdhbGxlcnlfd2lkdGgiOjYwMCwiZ2FsbGVyeV9oZWlnaHQiOjQwMCwidGh1bWJuYWlsX3dpZHRoIjoxMjAsInRodW1ibmFpbF9oZWlnaHQiOjkwLCJjeWNsZV9pbnRlcnZhbCI6MTAsImN5Y2xlX2VmZmVjdCI6ImZhZGUiLCJlZmZlY3RfY29kZSI6ImNsYXNzPVwibmdnLWZhbmN5Ym94XCIgcmVsPVwiJUdBTExFUllfTkFNRSVcIiIsInNob3dfdGh1bWJuYWlsX2xpbmsiOjEsInRodW1ibmFpbF9saW5rX3RleHQiOiJbU2hvdyB0aHVtYm5haWxzXSIsInRlbXBsYXRlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciJ9LCJoaWRkZW5fZnJvbV91aSI6ZmFsc2UsIl9fZGVmYXVsdHNfc2V0Ijp0cnVlfQ==', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=display_type&p=135', 0, 'display_type', '', 0),
(136, 2, '2015-03-14 18:38:22', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgSW1hZ2VCcm93c2VyIiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlwvbmV4dGdlbi1nYWxsZXJ5XC9wcm9kdWN0c1wvcGhvdG9jcmF0aV9uZXh0Z2VuXC9tb2R1bGVzXC9uZXh0Z2VuX2Jhc2ljX2ltYWdlYnJvd3Nlclwvc3RhdGljXC9wcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiZ2FsbGVyaWVzIiwidmlld19vcmRlciI6MTAwMjAsIm5hbWUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfaW1hZ2Vicm93c2VyIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIyLjAuNzcuMyIsImlkX2ZpZWxkIjoiSUQiLCJzZXR0aW5ncyI6eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJ0ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 'NextGEN Basic ImageBrowser', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-14 18:38:22', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgSW1hZ2VCcm93c2VyIiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlwvbmV4dGdlbi1nYWxsZXJ5XC9wcm9kdWN0c1wvcGhvdG9jcmF0aV9uZXh0Z2VuXC9tb2R1bGVzXC9uZXh0Z2VuX2Jhc2ljX2ltYWdlYnJvd3Nlclwvc3RhdGljXC9wcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiZ2FsbGVyaWVzIiwidmlld19vcmRlciI6MTAwMjAsIm5hbWUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfaW1hZ2Vicm93c2VyIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIyLjAuNzcuMyIsImlkX2ZpZWxkIjoiSUQiLCJzZXR0aW5ncyI6eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJ0ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=display_type&p=136', 0, 'display_type', '', 0),
(137, 2, '2015-03-14 18:38:22', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgU2luZ2xlUGljIiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlwvbmV4dGdlbi1nYWxsZXJ5XC9wcm9kdWN0c1wvcGhvdG9jcmF0aV9uZXh0Z2VuXC9tb2R1bGVzXC9uZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpY1wvc3RhdGljXC9wcmV2aWV3LmdpZiIsImRlZmF1bHRfc291cmNlIjoiZ2FsbGVyaWVzIiwidmlld19vcmRlciI6MTAwNjAsImhpZGRlbl9mcm9tX3VpIjp0cnVlLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpYyIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMi4wLjc3LjMiLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwid2lkdGgiOiIiLCJoZWlnaHQiOiIiLCJtb2RlIjoiIiwiZGlzcGxheV93YXRlcm1hcmsiOjAsImRpc3BsYXlfcmVmbGVjdGlvbiI6MCwiZmxvYXQiOiIiLCJsaW5rIjoiIiwibGlua190YXJnZXQiOiJfYmxhbmsiLCJxdWFsaXR5IjoxMDAsImNyb3AiOjAsInRlbXBsYXRlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciJ9LCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 'NextGEN Basic SinglePic', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-14 18:38:22', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgU2luZ2xlUGljIiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlwvbmV4dGdlbi1nYWxsZXJ5XC9wcm9kdWN0c1wvcGhvdG9jcmF0aV9uZXh0Z2VuXC9tb2R1bGVzXC9uZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpY1wvc3RhdGljXC9wcmV2aWV3LmdpZiIsImRlZmF1bHRfc291cmNlIjoiZ2FsbGVyaWVzIiwidmlld19vcmRlciI6MTAwNjAsImhpZGRlbl9mcm9tX3VpIjp0cnVlLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpYyIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMi4wLjc3LjMiLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwid2lkdGgiOiIiLCJoZWlnaHQiOiIiLCJtb2RlIjoiIiwiZGlzcGxheV93YXRlcm1hcmsiOjAsImRpc3BsYXlfcmVmbGVjdGlvbiI6MCwiZmxvYXQiOiIiLCJsaW5rIjoiIiwibGlua190YXJnZXQiOiJfYmxhbmsiLCJxdWFsaXR5IjoxMDAsImNyb3AiOjAsInRlbXBsYXRlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciJ9LCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=display_type&p=137', 0, 'display_type', '', 0),
(138, 2, '2015-03-14 18:38:22', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgVGFnQ2xvdWQiLCJlbnRpdHlfdHlwZXMiOlsiaW1hZ2UiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoiXC9uZXh0Z2VuLWdhbGxlcnlcL3Byb2R1Y3RzXC9waG90b2NyYXRpX25leHRnZW5cL21vZHVsZXNcL25leHRnZW5fYmFzaWNfdGFnY2xvdWRcL3N0YXRpY1wvcHJldmlldy5naWYiLCJkZWZhdWx0X3NvdXJjZSI6InRhZ3MiLCJ2aWV3X29yZGVyIjoxMDEwMCwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190YWdjbG91ZCIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMi4wLjc3LjMiLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZGlzcGxheV90eXBlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiLCJudW1iZXIiOjQ1LCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'NextGEN Basic TagCloud', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-14 18:38:22', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgVGFnQ2xvdWQiLCJlbnRpdHlfdHlwZXMiOlsiaW1hZ2UiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoiXC9uZXh0Z2VuLWdhbGxlcnlcL3Byb2R1Y3RzXC9waG90b2NyYXRpX25leHRnZW5cL21vZHVsZXNcL25leHRnZW5fYmFzaWNfdGFnY2xvdWRcL3N0YXRpY1wvcHJldmlldy5naWYiLCJkZWZhdWx0X3NvdXJjZSI6InRhZ3MiLCJ2aWV3X29yZGVyIjoxMDEwMCwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190YWdjbG91ZCIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMi4wLjc3LjMiLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZGlzcGxheV90eXBlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiLCJudW1iZXIiOjQ1LCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=display_type&p=138', 0, 'display_type', '', 0),
(139, 2, '2015-03-14 18:38:22', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgQ29tcGFjdCBBbGJ1bSIsImVudGl0eV90eXBlcyI6WyJhbGJ1bSIsImdhbGxlcnkiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoiXC9uZXh0Z2VuLWdhbGxlcnlcL3Byb2R1Y3RzXC9waG90b2NyYXRpX25leHRnZW5cL21vZHVsZXNcL25leHRnZW5fYmFzaWNfYWxidW1cL3N0YXRpY1wvY29tcGFjdF9wcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiYWxidW1zIiwidmlld19vcmRlciI6MTAyMDAsIm5hbWUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfY29tcGFjdF9hbGJ1bSIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMi4wLjc3LjMiLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZ2FsbGVyaWVzX3Blcl9wYWdlIjowLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsInRlbXBsYXRlIjoiIiwiZ2FsbGVyeV9kaXNwbGF5X3R5cGUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsImdhbGxlcnlfZGlzcGxheV90ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 'NextGEN Basic Compact Album', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-14 18:38:22', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgQ29tcGFjdCBBbGJ1bSIsImVudGl0eV90eXBlcyI6WyJhbGJ1bSIsImdhbGxlcnkiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoiXC9uZXh0Z2VuLWdhbGxlcnlcL3Byb2R1Y3RzXC9waG90b2NyYXRpX25leHRnZW5cL21vZHVsZXNcL25leHRnZW5fYmFzaWNfYWxidW1cL3N0YXRpY1wvY29tcGFjdF9wcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiYWxidW1zIiwidmlld19vcmRlciI6MTAyMDAsIm5hbWUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfY29tcGFjdF9hbGJ1bSIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMi4wLjc3LjMiLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZ2FsbGVyaWVzX3Blcl9wYWdlIjowLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsInRlbXBsYXRlIjoiIiwiZ2FsbGVyeV9kaXNwbGF5X3R5cGUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsImdhbGxlcnlfZGlzcGxheV90ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=display_type&p=139', 0, 'display_type', '', 0),
(140, 2, '2015-03-14 18:38:22', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgRXh0ZW5kZWQgQWxidW0iLCJlbnRpdHlfdHlwZXMiOlsiYWxidW0iLCJnYWxsZXJ5Il0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlwvbmV4dGdlbi1nYWxsZXJ5XC9wcm9kdWN0c1wvcGhvdG9jcmF0aV9uZXh0Z2VuXC9tb2R1bGVzXC9uZXh0Z2VuX2Jhc2ljX2FsYnVtXC9zdGF0aWNcL2V4dGVuZGVkX3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJhbGJ1bXMiLCJ2aWV3X29yZGVyIjoxMDIxMCwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19leHRlbmRlZF9hbGJ1bSIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMi4wLjc3LjMiLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZ2FsbGVyaWVzX3Blcl9wYWdlIjowLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsInRlbXBsYXRlIjoiIiwib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjowLCJ0aHVtYm5haWxfd2lkdGgiOjEyMCwidGh1bWJuYWlsX2hlaWdodCI6OTAsInRodW1ibmFpbF9xdWFsaXR5IjoxMDAsInRodW1ibmFpbF9jcm9wIjp0cnVlLCJ0aHVtYm5haWxfd2F0ZXJtYXJrIjowLCJnYWxsZXJ5X2Rpc3BsYXlfdHlwZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwiZ2FsbGVyeV9kaXNwbGF5X3RlbXBsYXRlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciJ9LCJoaWRkZW5fZnJvbV91aSI6ZmFsc2UsIl9fZGVmYXVsdHNfc2V0Ijp0cnVlfQ==', 'NextGEN Basic Extended Album', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-14 18:38:22', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgRXh0ZW5kZWQgQWxidW0iLCJlbnRpdHlfdHlwZXMiOlsiYWxidW0iLCJnYWxsZXJ5Il0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlwvbmV4dGdlbi1nYWxsZXJ5XC9wcm9kdWN0c1wvcGhvdG9jcmF0aV9uZXh0Z2VuXC9tb2R1bGVzXC9uZXh0Z2VuX2Jhc2ljX2FsYnVtXC9zdGF0aWNcL2V4dGVuZGVkX3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJhbGJ1bXMiLCJ2aWV3X29yZGVyIjoxMDIxMCwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19leHRlbmRlZF9hbGJ1bSIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMi4wLjc3LjMiLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZ2FsbGVyaWVzX3Blcl9wYWdlIjowLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsInRlbXBsYXRlIjoiIiwib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjowLCJ0aHVtYm5haWxfd2lkdGgiOjEyMCwidGh1bWJuYWlsX2hlaWdodCI6OTAsInRodW1ibmFpbF9xdWFsaXR5IjoxMDAsInRodW1ibmFpbF9jcm9wIjp0cnVlLCJ0aHVtYm5haWxfd2F0ZXJtYXJrIjowLCJnYWxsZXJ5X2Rpc3BsYXlfdHlwZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwiZ2FsbGVyeV9kaXNwbGF5X3RlbXBsYXRlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciJ9LCJoaWRkZW5fZnJvbV91aSI6ZmFsc2UsIl9fZGVmYXVsdHNfc2V0Ijp0cnVlfQ==', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=display_type&p=140', 0, 'display_type', '', 0),
(141, 2, '2015-03-14 18:44:25', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_gallery', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2015-03-14 18:44:25', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=141', 0, 'ngg_gallery', '', 0),
(142, 2, '2015-03-14 18:44:25', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2015-03-14 18:44:25', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=142', 0, 'ngg_pictures', '', 0),
(143, 2, '2015-03-14 18:45:25', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2015-03-14 18:45:25', '2015-03-14 18:45:25', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=143', 0, 'ngg_pictures', '', 0),
(144, 2, '2015-03-14 18:45:25', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_gallery', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2015-03-14 18:45:25', '2015-03-14 18:45:25', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=144', 0, 'ngg_gallery', '', 0),
(145, 2, '2015-03-14 18:44:26', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2015-03-14 18:44:26', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=145', 0, 'ngg_pictures', '', 0),
(146, 2, '2015-03-14 18:45:25', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2015-03-14 18:45:25', '2015-03-14 18:45:25', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=146', 0, 'ngg_pictures', '', 0),
(147, 2, '2015-03-14 18:44:26', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2015-03-14 18:44:26', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=147', 0, 'ngg_pictures', '', 0),
(148, 2, '2015-03-14 18:45:25', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2015-03-14 18:45:25', '2015-03-14 18:45:25', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=148', 0, 'ngg_pictures', '', 0),
(149, 2, '2015-03-14 18:45:59', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_album', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2015-03-14 18:45:59', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://sanctuary.lisawolfsonmyers.com/?post_type=ngg_album&p=149', 0, 'ngg_album', '', 0),
(150, 2, '2015-03-14 18:59:14', '2015-03-14 18:59:14', '', 'cabin1', '', 'inherit', 'closed', 'closed', '', 'cabin1', '', '', '2015-03-14 18:59:14', '2015-03-14 18:59:14', '', 0, 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/cabin1.jpg', 0, 'attachment', 'image/jpeg', 0),
(151, 2, '2015-03-14 18:59:15', '2015-03-14 18:59:15', '', 'cabin2', '', 'inherit', 'closed', 'closed', '', 'cabin2', '', '', '2015-03-14 18:59:15', '2015-03-14 18:59:15', '', 0, 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/cabin2.jpg', 0, 'attachment', 'image/jpeg', 0),
(152, 2, '2015-03-14 18:59:15', '2015-03-14 18:59:15', '', 'cabin3', '', 'inherit', 'closed', 'closed', '', 'cabin3', '', '', '2015-03-14 18:59:15', '2015-03-14 18:59:15', '', 0, 'http://sanctuary.lisawolfsonmyers.com/wp-content/uploads/2015/03/cabin3.jpg', 0, 'attachment', 'image/jpeg', 0),
(153, 2, '2015-03-14 21:07:26', '0000-00-00 00:00:00', '', 'Orchard Painter\'s Cabin', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-03-14 21:07:26', '0000-00-00 00:00:00', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=153', 1, 'nav_menu_item', '', 0),
(154, 2, '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 'Orchard Painter\'s Cabin', '', 'publish', 'closed', 'closed', '', 'orchard-painters-cabin-2', '', '', '2015-03-14 21:08:19', '2015-03-14 21:08:19', '', 0, 'http://sanctuary.lisawolfsonmyers.com/?p=154', 3, 'nav_menu_item', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(4, 1, 0),
(30, 4, 0),
(31, 4, 0),
(32, 4, 0),
(34, 4, 0),
(35, 4, 0),
(36, 4, 0),
(44, 5, 0),
(45, 5, 0),
(46, 5, 0),
(47, 5, 0),
(48, 5, 0),
(72, 6, 0),
(73, 6, 0),
(74, 6, 0),
(75, 6, 0),
(103, 4, 0),
(104, 4, 0),
(105, 4, 0),
(106, 4, 0),
(107, 4, 0),
(108, 4, 0),
(109, 4, 0),
(111, 4, 0),
(130, 8, 0),
(131, 8, 0),
(154, 4, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(4, 4, 'nav_menu', '', 0, 15),
(5, 5, 'ml-slider', '', 0, 0),
(6, 6, 'nav_menu', '', 0, 4),
(8, 8, 'category', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(4, 'Primary Nav', 'primary-nav', 0),
(5, '43', '43', 0),
(6, 'Social', 'social', 0),
(8, 'Painter\'s', 'painters', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(29, 2, 'nickname', 'lwolfson'),
(30, 2, 'first_name', 'Lisa'),
(31, 2, 'last_name', 'Wolfson'),
(32, 2, 'description', ''),
(33, 2, 'rich_editing', 'true'),
(34, 2, 'comment_shortcuts', 'false'),
(35, 2, 'admin_color', 'fresh'),
(36, 2, 'use_ssl', '0'),
(37, 2, 'show_admin_bar_front', 'true'),
(38, 2, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(39, 2, 'wp_user_level', '10'),
(40, 2, 'dismissed_wp_pointers', 'wp360_locks,wp390_widgets,wp410_dfw'),
(42, 2, 'wp_dashboard_quick_press_last_post_id', '71'),
(43, 2, 'nav_menu_recently_edited', '4'),
(44, 2, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(45, 2, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'),
(46, 2, 'closedpostboxes_page', 'a:0:{}'),
(47, 2, 'metaboxhidden_page', 'a:6:{i:0;s:6:"acf_53";i:1;s:10:"postcustom";i:2;s:16:"commentstatusdiv";i:3;s:11:"commentsdiv";i:4;s:7:"slugdiv";i:5;s:9:"authordiv";}'),
(48, 2, 'wp_user-settings', 'libraryContent=browse'),
(49, 2, 'wp_user-settings-time', '1426193800'),
(52, 2, 'closedpostboxes_slideshow_page_slideshow-settings', 'a:1:{i:0;s:10:"pluginsdiv";}'),
(53, 2, 'metaboxhidden_slideshow_page_slideshow-settings', 'a:0:{}'),
(54, 2, 'session_tokens', 'a:1:{s:64:"6c0025af30fc11d672ba06bca894e7b3c788fa155675504d3df83e9b4ee763f0";a:4:{s:10:"expiration";i:1426535819;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36";s:5:"login";i:1426363019;}}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(2, 'lwolfson', '$P$B6QPjH2JN6Jb.lzlODcUJH1Mm0h62F/', 'lwolfson', 'lisa.wolfson@gmail.com', 'http://sanctuary.lisawolfsonmyers.com', '2015-03-09 17:59:01', '', 0, 'Lisa Wolfson') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in
#

